package main

import "time"

type Pet struct {
	Stage     LifeStage
	Hunger    int
	Happiness int
	Health    int
	Coding    int
	BornAt    time.Time
}

type LifeStage int

const (
	StageEgg LifeStage = iota
	StageBaby
	StageChild
	StageTeen
	StageAdult
	StageElder
)

// Short timings so you can see every stage during a workshop (~1 min each).
const (
	eggHatchDuration  = 1 * time.Minute
	stageStepDuration = 1 * time.Minute
)

const (
	gopherEgg     = 'O'
	gopherBaby    = 'D'
	gopherChild   = 'E'
	gopherTeen    = 'Y'
	gopherDefault = 'B'
	gopherOld     = 'Z'
)

func NewPet() *Pet {
	return &Pet{
		Stage:     StageEgg,
		Hunger:    50,
		Happiness: 70,
		Health:    100,
		Coding:    50,
		BornAt:    time.Now(),
	}
}

// Update only advances the life stage (stats stay fixed in this step).
func (p *Pet) Update() {
	p.updateStage()
}

func (p *Pet) updateStage() {
	if next := stageAt(time.Since(p.BornAt)); next != p.Stage {
		p.Stage = next
	}
}

func stageAt(age time.Duration) LifeStage {
	if age < eggHatchDuration {
		return StageEgg
	}
	age -= eggHatchDuration
	switch int(age / stageStepDuration) {
	case 0:
		return StageBaby
	case 1:
		return StageChild
	case 2:
		return StageTeen
	case 3:
		return StageAdult
	default:
		return StageElder
	}
}

func (p *Pet) GetGopherChar() rune {
	switch p.Stage {
	case StageEgg:
		return gopherEgg
	case StageBaby:
		return gopherBaby
	case StageChild:
		return gopherChild
	case StageTeen:
		return gopherTeen
	case StageAdult:
		return gopherDefault
	case StageElder:
		return gopherOld
	default:
		return gopherDefault
	}
}

func (p *Pet) StageLabel() string {
	switch p.Stage {
	case StageEgg:
		return "egg"
	case StageBaby:
		return "baby"
	case StageChild:
		return "child"
	case StageTeen:
		return "teenager"
	case StageAdult:
		return "adult"
	case StageElder:
		return "elder"
	default:
		return "baby"
	}
}
