// Step 3: step 2 display + life-stage evolution (no buttons yet — see step 4).
package main

import (
	"image/color"
	"machine"
	"time"

	"tinygo.org/x/drivers/st7789"
	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/gophers"
)

const gopherScale = 3

var (
	display    st7789.Device
	gopherFont = &gophers.Regular58pt

	gopherBlue = color.RGBA{R: 0, G: 173, B: 216, A: 255}
	white      = color.RGBA{R: 255, G: 255, B: 255, A: 255}
)

func main() {
	initDisplay()

	pet := NewPet()
	redrawScreen(pet)
	onScreen := captureScreenState(pet)

	ticker := time.NewTicker(100 * time.Millisecond)
	for range ticker.C {
		pet.Update()

		next := captureScreenState(pet)
		if next != onScreen {
			redrawScreen(pet)
			onScreen = next
		}
	}
}

func redrawScreen(pet *Pet) {
	display.FillScreen(white)
	drawGopherLeft(pet.GetGopherChar(), gopherBlue)
	drawStageLabel(pet)
	drawStats(pet)
}

func drawGopherLeft(char rune, col color.RGBA) {
	glyph := gopherFont.GetGlyph(char)
	drawCharScaled(glyph, gopherDrawX, gopherDrawY, gopherScale, col)
}

func drawCharScaled(glyph tinyfont.Glypher, x, y, scale int16, col color.RGBA) {
	g, ok := glyph.(*tinyfont.Glyph)
	if !ok || scale <= 1 {
		tinyfont.DrawChar(&display, gopherFont, x, y, glyph.Info().Rune, col)
		return
	}

	bitmapOffset := 0
	bitmap := byte(0)
	if len(g.Bitmaps) > 0 {
		bitmap = g.Bitmaps[bitmapOffset]
	}
	bit := uint8(0)
	for j := int16(0); j < int16(g.Height); j++ {
		for i := int16(0); i < int16(g.Width); i++ {
			if bitmap&0x80 != 0 {
				px := x + (int16(g.XOffset)+i)*scale
				py := y + (int16(g.YOffset)+j)*scale
				display.FillRectangle(px, py, scale, scale, col)
			}
			bitmap <<= 1
			bit++
			if bit > 7 {
				bitmapOffset++
				if bitmapOffset < len(g.Bitmaps) {
					bitmap = g.Bitmaps[bitmapOffset]
				}
				bit = 0
			}
		}
	}
}

func initDisplay() {
	machine.SPI0.Configure(machine.SPIConfig{
		Frequency: 8000000,
		Mode:      0,
	})

	display = st7789.New(machine.SPI0,
		machine.TFT_RST,
		machine.TFT_WRX,
		machine.TFT_CS,
		machine.TFT_BACKLIGHT,
	)

	display.Configure(st7789.Config{
		Rotation: st7789.ROTATION_270,
		Height:   320,
	})
}
