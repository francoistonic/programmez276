package main

import (
	"image/color"
	"machine"

	"tinygo.org/x/drivers/st7789"
	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/freemono"
	"tinygo.org/x/tinyfont/gophers"
)

// Pet represents the virtual pet with its stats and state
type Pet struct {
	Name      string
	Stage     int // Life stage (0=egg, 1=baby, etc.)
	Hunger    int // Hunger level (0-100)
	Happiness int // Happiness level (0-100)
	Health    int // Health level (0-100)
	Coding    int // Coding skill level (0-100)
}

var (
	display    st7789.Device
	gopherBlue = color.RGBA{R: 0, G: 173, B: 216, A: 255}
	white      = color.RGBA{R: 255, G: 255, B: 255, A: 255}
	black      = color.RGBA{R: 0, G: 0, B: 0, A: 255}
	lightGray  = color.RGBA{R: 200, G: 200, B: 200, A: 255}
	red        = color.RGBA{R: 255, G: 0, B: 0, A: 255}
	green      = color.RGBA{R: 0, G: 200, B: 0, A: 255}
	yellow     = color.RGBA{R: 255, G: 200, B: 0, A: 255}
)

func main() {
	initDisplay()

	// Create a new pet with initial stats
	pet := &Pet{
		Name:      "Gopher",
		Hunger:    50,
		Happiness: 70,
		Health:    100,
		Coding:    50,
	}

	// Clear screen
	display.FillScreen(white)

	// Draw the gopher on the left side
	tinyfont.DrawChar(&display, &gophers.Regular121pt, 20, 160, 'B', gopherBlue)

	// Draw the stats on the right side
	drawStats(pet)
}

// drawStats displays all four statistics with icons and progress bars
func drawStats(pet *Pet) {
	x := int16(160) // Stats column starts at x=160
	y := int16(38)  // First stat starts below the title

	// Draw each stat: icon, label, and colored bar
	drawStatRow(x, y, pet.Hunger, "Hunger", drawBowlIcon)
	y += 35 // Move down for next stat

	drawStatRow(x, y, pet.Happiness, "Happy", drawHeartIcon)
	y += 35

	drawStatRow(x, y, pet.Health, "Health", drawCrossIcon)
	y += 35

	drawStatRow(x, y, pet.Coding, "Coding", drawCodeIcon)
}

// drawStatRow draws one complete stat line: icon + label + progress bar
func drawStatRow(x, y int16, value int, label string, drawIcon func(x, y int16)) {
	// Draw the icon
	drawIcon(x, y+1)

	// Draw the label text next to the icon
	textX := x + 18 // Offset text to the right of icon
	tinyfont.WriteLine(&display, &freemono.Bold9pt7b, textX, y+10, label, black)

	// Draw the progress bar below the label
	barY := y + 24
	drawProgressBar(textX, barY, value)
}

// drawProgressBar draws a colored bar based on the stat value
func drawProgressBar(x, y int16, value int) {
	barWidth := int16(100)
	barHeight := int16(10)

	// Draw gray background
	display.FillRectangle(x, y, barWidth, barHeight, lightGray)

	// Draw colored fill based on value (0-100)
	fillWidth := int16(value) * barWidth / 100
	if fillWidth > 0 {
		// Color changes based on value: green > 60, yellow 30-60, red < 30
		barColor := green
		if value <= 60 {
			barColor = yellow
		}
		if value <= 30 {
			barColor = red
		}
		display.FillRectangle(x, y, fillWidth, barHeight, barColor)
	}
}

// Icon drawing functions (simple pixel art)
func drawBowlIcon(x, y int16) {
	// Bowl base
	display.FillRectangle(x, y+8, 12, 2, black)
	// Bowl sides
	display.FillRectangle(x, y+6, 2, 4, black)
	display.FillRectangle(x+10, y+6, 2, 4, black)
	// Bowl content
	display.FillRectangle(x+2, y+3, 8, 5, gopherBlue)
}

func drawHeartIcon(x, y int16) {
	// Heart top curves
	display.FillRectangle(x+2, y+1, 3, 3, red)
	display.FillRectangle(x+7, y+1, 3, 3, red)
	// Heart middle
	display.FillRectangle(x+1, y+3, 10, 3, red)
	// Heart bottom point
	display.FillRectangle(x+2, y+6, 8, 2, red)
	display.FillRectangle(x+3, y+8, 6, 1, red)
}

func drawCrossIcon(x, y int16) {
	// Medical cross
	display.FillRectangle(x+4, y+1, 4, 9, green) // Vertical bar
	display.FillRectangle(x+2, y+4, 8, 3, green) // Horizontal bar
}

func drawCodeIcon(x, y int16) {
	// Simplified laptop/screen icon
	display.FillRectangle(x+2, y+1, 3, 8, yellow) // Screen
	display.FillRectangle(x+5, y+5, 3, 4, black)  // Keyboard
	display.FillRectangle(x+7, y+8, 2, 2, black)  // Keyboard detail
}

func initDisplay() {
	machine.SPI0.Configure(machine.SPIConfig{
		Frequency: 8000000,
		Mode:      0,
	})

	display = st7789.New(machine.SPI0,
		machine.TFT_RST,
		machine.TFT_WRX,
		machine.TFT_CS,
		machine.TFT_BACKLIGHT,
	)

	display.Configure(st7789.Config{
		Rotation: st7789.ROTATION_270,
		Height:   320,
	})
}
