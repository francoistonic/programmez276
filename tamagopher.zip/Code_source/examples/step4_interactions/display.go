package main

import (
	"image/color"

	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/freemono"
	"tinygo.org/x/tinyfont/notoemoji"
)

var emojiFont = &notoemoji.NotoEmojiRegular20pt

const (
	emojiFeed  = '\u2668'
	emojiPlay  = '\u26BD'
	emojiClean = '\u2728'
	emojiMed   = '\u26A1'
	emojiCode  = '\u270F'
	emojiReset = '\u21A9'
	gameTitle  = "Tamagopher"
)

var (
	black     = color.RGBA{R: 0, G: 0, B: 0, A: 255}
	lightGray = color.RGBA{R: 200, G: 200, B: 200, A: 255}
	red       = color.RGBA{R: 255, G: 0, B: 0, A: 255}
	green     = color.RGBA{R: 0, G: 200, B: 0, A: 255}
	yellow    = color.RGBA{R: 255, G: 200, B: 0, A: 255}
)

const (
	statsStartX     = 160
	statsStartY     = 38
	statIconW       = 14
	statTextX       = statsStartX + statIconW + 4
	statLabelY      = 10
	statLabelBarGap = 4
	statBarH        = 10
	statBarW        = 100
	statRowStride   = statLabelY + statLabelBarGap + statBarH + 11

	stageLabelX = 10
	stageLabelY = 20
	gopherDrawX = 20
	gopherDrawY = 160

	actionRow1Y  = 186
	actionRow2Y  = 214
	actionCol1X  = 14
	actionCol2X  = 114
	actionCol3X  = 214
	actionLabelX = 28
	emojiSlotW   = 22
	emojiSlotH   = 20

	actionSelectPadX      = 2
	actionSelectPadTop    = 10
	actionSelectPadBottom = 3
	actionSelectMinW      = 90
)

type screenState struct {
	stage     LifeStage
	gopher    rune
	selected  Action
	hunger    int
	happiness int
	health    int
	coding    int
	allowed   uint8
}

func captureScreenState(pet *Pet, menu *ActionMenu) screenState {
	s := screenState{
		stage:    pet.Stage,
		gopher:   pet.GetGopherChar(),
		selected: menu.Selected,
		hunger:   pet.Hunger,
		health:   pet.Health,
	}
	if pet.Stage != StageEgg {
		s.happiness = pet.Happiness
		s.coding = pet.Coding
	}
	for a := Action(0); a < ActionCount; a++ {
		if pet.IsActionAllowed(a) {
			s.allowed |= 1 << a
		}
	}
	return s
}

func drawStageLabel(pet *Pet) {
	drawText(stageLabelX, stageLabelY, gameTitle+": "+pet.StageLabel(), black)
}

func drawStats(pet *Pet) {
	y := int16(statsStartY)
	drawStatRow(y, pet.Hunger, "Hunger", drawBowlIcon)
	y += statRowStride
	if pet.Stage != StageEgg {
		drawStatRow(y, pet.Happiness, "Happy", drawHeartIcon)
		y += statRowStride
	}
	drawStatRow(y, pet.Health, "Health", drawCrossIcon)
	y += statRowStride
	if pet.Stage != StageEgg {
		drawStatRow(y, pet.Coding, "Coding", drawCodeIcon)
	}
}

func drawStatRow(rowY int16, value int, label string, drawIcon func(x, y int16)) {
	drawIcon(statsStartX, rowY+1)
	drawText(statTextX, rowY+statLabelY, label, black)
	drawStatBarAt(statTextX, rowY+statLabelY+statLabelBarGap, value)
}

func drawActions(selected Action, pet *Pet) {
	drawAction(actionCol1X, actionRow1Y, emojiFeed, "Feed", selected == ActionFeed, pet.IsActionAllowed(ActionFeed))
	drawAction(actionCol2X, actionRow1Y, emojiPlay, "Play", selected == ActionPlay, pet.IsActionAllowed(ActionPlay))
	drawAction(actionCol3X, actionRow1Y, emojiClean, "Clean", selected == ActionClean, pet.IsActionAllowed(ActionClean))
	drawAction(actionCol1X, actionRow2Y, emojiMed, "Med", selected == ActionMed, pet.IsActionAllowed(ActionMed))
	drawAction(actionCol2X, actionRow2Y, emojiCode, "Coding", selected == ActionCoding, pet.IsActionAllowed(ActionCoding))
	drawAction(actionCol3X, actionRow2Y, emojiReset, "Reset", selected == ActionReset, pet.IsActionAllowed(ActionReset))
}

func drawAction(x, y int16, emoji rune, label string, selected, enabled bool) {
	selectW := actionSelectWidth(label)
	if selected && enabled {
		display.FillRectangle(
			x-actionSelectPadX,
			y-actionSelectPadTop,
			selectW,
			actionSelectPadTop+emojiSlotH+actionSelectPadBottom,
			gopherBlue,
		)
	}
	emojiColor := black
	if !enabled {
		emojiColor = lightGray
	}
	drawEmojiInSlot(emoji, x, y, emojiSlotW, emojiSlotH, emojiColor)
	textColor := black
	if !enabled {
		textColor = lightGray
	} else if selected {
		textColor = white
	}
	drawText(x+actionLabelX, y+5, label, textColor)
}

func actionSelectWidth(label string) int16 {
	w, _ := tinyfont.LineWidth(&freemono.Bold9pt7b, label)
	boxW := actionLabelX + int16(w) + actionSelectPadX + 4
	if boxW < actionSelectMinW {
		return actionSelectMinW
	}
	return boxW
}

func drawEmojiInSlot(r rune, sx, sy, w, h int16, c color.RGBA) {
	glyph := emojiFont.GetGlyph(r)
	info := glyph.Info()
	if info.Width == 0 && info.Height == 0 && r != 0 {
		return
	}
	_, outer := tinyfont.LineWidth(emojiFont, string(r))
	ex := sx + (w-int16(outer))/2
	ey := sy + h - 6
	tinyfont.DrawChar(&display, emojiFont, ex, ey, r, c)
}

func drawStatBarAt(x, barY int16, value int) {
	display.FillRectangle(x, barY, statBarW, statBarH, lightGray)
	fillWidth := int16(value) * statBarW / 100
	if fillWidth > 0 {
		display.FillRectangle(x, barY, fillWidth, statBarH, getStatColor(value))
	}
}

func getStatColor(value int) color.RGBA {
	if value > 60 {
		return green
	} else if value > 30 {
		return yellow
	}
	return red
}

func drawText(x, y int16, text string, col color.RGBA) {
	tinyfont.WriteLine(&display, &freemono.Bold9pt7b, x, y, text, col)
}

func drawBowlIcon(x, y int16) {
	display.FillRectangle(x, y+8, 12, 2, black)
	display.FillRectangle(x, y+6, 2, 4, black)
	display.FillRectangle(x+10, y+6, 2, 4, black)
	display.FillRectangle(x+2, y+3, 8, 5, gopherBlue)
}

func drawHeartIcon(x, y int16) {
	display.FillRectangle(x+2, y+1, 3, 3, red)
	display.FillRectangle(x+7, y+1, 3, 3, red)
	display.FillRectangle(x+1, y+3, 10, 3, red)
	display.FillRectangle(x+2, y+6, 8, 2, red)
	display.FillRectangle(x+3, y+8, 6, 1, red)
}

func drawCrossIcon(x, y int16) {
	display.FillRectangle(x+4, y+1, 4, 9, green)
	display.FillRectangle(x+2, y+4, 8, 3, green)
}

func drawCodeIcon(x, y int16) {
	display.FillRectangle(x+2, y+1, 3, 8, yellow)
	display.FillRectangle(x+5, y+5, 3, 4, black)
	display.FillRectangle(x+7, y+8, 2, 2, black)
}
