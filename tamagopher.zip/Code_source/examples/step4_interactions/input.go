package main

import "machine"

type ButtonState struct {
	UpPressed    bool
	DownPressed  bool
	LeftPressed  bool
	RightPressed bool
	APressed     bool
}

func initButtons() {
	machine.BUTTON_UP.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	machine.BUTTON_DOWN.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	machine.BUTTON_LEFT.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	machine.BUTTON_RIGHT.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	machine.BUTTON_A.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	machine.BUTTON_B.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
}

func readButtons() ButtonState {
	return ButtonState{
		UpPressed:    !machine.BUTTON_UP.Get(),
		DownPressed:  !machine.BUTTON_DOWN.Get(),
		LeftPressed:  !machine.BUTTON_LEFT.Get(),
		RightPressed: !machine.BUTTON_RIGHT.Get(),
		APressed:     !machine.BUTTON_A.Get(),
	}
}
