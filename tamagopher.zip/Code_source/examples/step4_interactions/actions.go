package main

type Action int

const (
	ActionFeed Action = iota
	ActionPlay
	ActionClean
	ActionMed
	ActionCoding
	ActionReset
	ActionCount
)

type ActionMenu struct {
	Selected Action
}

func NewActionMenu() *ActionMenu {
	return &ActionMenu{Selected: ActionFeed}
}

func (m *ActionMenu) MoveRight(pet *Pet) {
	m.moveBy(pet, 1)
}

func (m *ActionMenu) MoveLeft(pet *Pet) {
	m.moveBy(pet, -1)
}

func (m *ActionMenu) MoveDown(pet *Pet) {
	if m.Selected < ActionMed {
		m.Selected += 3
	} else {
		m.moveBy(pet, 1)
	}
	m.clampToAllowed(pet)
}

func (m *ActionMenu) MoveUp(pet *Pet) {
	if m.Selected >= ActionMed {
		m.Selected -= 3
	} else {
		m.moveBy(pet, -1)
	}
	m.clampToAllowed(pet)
}

func (m *ActionMenu) EnsureSelection(pet *Pet) {
	m.clampToAllowed(pet)
}

func (m *ActionMenu) moveBy(pet *Pet, delta int) {
	for i := 0; i < int(ActionCount); i++ {
		next := int(m.Selected) + delta
		if next < 0 {
			next += int(ActionCount)
		}
		m.Selected = Action(next % int(ActionCount))
		if pet.IsActionAllowed(m.Selected) {
			return
		}
	}
}

func (m *ActionMenu) clampToAllowed(pet *Pet) {
	if pet.IsActionAllowed(m.Selected) {
		return
	}
	m.moveBy(pet, 1)
}

func (m *ActionMenu) Execute(pet *Pet) {
	if !pet.IsActionAllowed(m.Selected) {
		return
	}
	switch m.Selected {
	case ActionFeed:
		pet.Feed()
	case ActionPlay:
		pet.Play()
	case ActionClean:
		pet.Clean()
	case ActionMed:
		pet.GiveMedicine()
	case ActionCoding:
		pet.DoCoding()
	case ActionReset:
		pet.Reset()
		m.EnsureSelection(pet)
	}
}
