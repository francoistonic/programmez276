package main

import "time"

type Pet struct {
	Stage      LifeStage
	Hunger     int
	Happiness  int
	Health     int
	Coding     int
	PoopCount  int
	IsSick     bool
	BornAt     time.Time
	LastUpdate time.Time
}

type LifeStage int

const (
	StageEgg LifeStage = iota
	StageBaby
	StageChild
	StageTeen
	StageAdult
	StageElder
)

const (
	eggHatchDuration  = 1 * time.Minute
	stageStepDuration = 1 * time.Minute
	statDecayInterval = 1 * time.Minute
)

const (
	gopherEgg     = 'O'
	gopherBaby    = 'D'
	gopherChild   = 'E'
	gopherTeen    = 'Y'
	gopherDefault = 'B'
	gopherOld     = 'Z'
)

func NewPet() *Pet {
	now := time.Now()
	return &Pet{
		Stage:      StageEgg,
		Hunger:     50,
		Happiness:  70,
		Health:     100,
		Coding:     50,
		BornAt:     now,
		LastUpdate: now,
	}
}

func (p *Pet) Update() {
	now := time.Now()
	elapsed := now.Sub(p.LastUpdate)

	if elapsed >= statDecayInterval {
		if p.Hunger > 0 {
			p.Hunger--
		}
		if p.Stage != StageEgg {
			if p.Happiness > 0 {
				p.Happiness--
			}
			if p.Coding > 0 {
				p.Coding--
			}
			if p.Hunger < 80 && p.PoopCount < 3 && (now.Unix()%4) == 0 {
				p.PoopCount++
			}
			if p.PoopCount >= 2 && p.Health < 50 && !p.IsSick && (now.Unix()%3) == 0 {
				p.IsSick = true
			}
		}
		if (p.Hunger < 15 || (p.Stage != StageEgg && p.PoopCount >= 3)) && p.Health > 0 {
			p.Health--
		}
		p.LastUpdate = now
	}

	p.updateStage()
}

func (p *Pet) updateStage() {
	if next := stageAt(time.Since(p.BornAt)); next != p.Stage {
		p.Stage = next
	}
}

func stageAt(age time.Duration) LifeStage {
	if age < eggHatchDuration {
		return StageEgg
	}
	age -= eggHatchDuration
	switch int(age / stageStepDuration) {
	case 0:
		return StageBaby
	case 1:
		return StageChild
	case 2:
		return StageTeen
	case 3:
		return StageAdult
	default:
		return StageElder
	}
}

func (p *Pet) GetGopherChar() rune {
	switch p.Stage {
	case StageEgg:
		return gopherEgg
	case StageBaby:
		return gopherBaby
	case StageChild:
		return gopherChild
	case StageTeen:
		return gopherTeen
	case StageAdult:
		return gopherDefault
	case StageElder:
		return gopherOld
	default:
		return gopherDefault
	}
}

func (p *Pet) StageLabel() string {
	switch p.Stage {
	case StageEgg:
		return "egg"
	case StageBaby:
		return "baby"
	case StageChild:
		return "child"
	case StageTeen:
		return "teenager"
	case StageAdult:
		return "adult"
	case StageElder:
		return "elder"
	default:
		return "baby"
	}
}

func (p *Pet) IsActionAllowed(a Action) bool {
	if a == ActionReset {
		return true
	}
	if p.Stage == StageEgg {
		return a == ActionFeed || a == ActionMed
	}
	return true
}

func (p *Pet) Feed() {
	p.Hunger = min(100, p.Hunger+30)
}

func (p *Pet) Play() {
	p.Happiness = min(100, p.Happiness+25)
	p.Hunger = max(0, p.Hunger-3)
	p.Coding = min(100, p.Coding+3)
}

func (p *Pet) Clean() {
	p.PoopCount = 0
	p.Happiness = min(100, p.Happiness+15)
}

func (p *Pet) GiveMedicine() {
	if p.IsSick {
		p.IsSick = false
		p.Health = min(100, p.Health+40)
	}
}

func (p *Pet) DoCoding() {
	p.Coding = min(100, p.Coding+20)
	p.Happiness = max(0, p.Happiness-3)
}

func (p *Pet) Reset() {
	now := time.Now()
	p.Stage = StageEgg
	p.Hunger = 50
	p.Happiness = 70
	p.Health = 100
	p.Coding = 50
	p.PoopCount = 0
	p.IsSick = false
	p.BornAt = now
	p.LastUpdate = now
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
