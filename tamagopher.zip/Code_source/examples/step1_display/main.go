package main

import (
	"image/color"
	"machine"

	"tinygo.org/x/drivers/st7789"
	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/gophers"
)

var (
	// Display driver for the ST7789 screen controller
	display st7789.Device

	// Define colors in RGBA format (Red, Green, Blue, Alpha)
	gopherBlue = color.RGBA{R: 0, G: 173, B: 216, A: 255}
	white      = color.RGBA{R: 255, G: 255, B: 255, A: 255}
)

func main() {
	// Initialize the screen hardware
	initDisplay()

	// Clear the entire screen with white color
	display.FillScreen(white)

	// Draw the gopher character 'B' (adult gopher) at position (100, 120)
	// The gophers font turns letters into different gopher drawings!
	// B = adult, O = egg, D = baby, E = child, X = teen, Z = elder
	tinyfont.DrawChar(&display, &gophers.Regular121pt, 100, 150, 'B', gopherBlue)
}

// initDisplay configures the SPI bus and initializes the ST7789 display driver
func initDisplay() {
	// Configure SPI0 (Serial Peripheral Interface) for communication with the screen
	// Frequency: 8 MHz is a safe speed for the ST7789 controller
	machine.SPI0.Configure(machine.SPIConfig{
		Frequency: 8000000,
		Mode:      0,
	})

	// Create the display driver with the necessary pins
	display = st7789.New(machine.SPI0,
		machine.TFT_RST,       // Reset pin
		machine.TFT_WRX,       // Data/Command select pin
		machine.TFT_CS,        // Chip Select pin
		machine.TFT_BACKLIGHT, // Backlight control pin
	)

	// Configure the display orientation and size
	// ROTATION_270 makes the screen landscape (320 wide × 240 tall)
	display.Configure(st7789.Config{
		Rotation: st7789.ROTATION_270,
		Height:   320,
	})
}
