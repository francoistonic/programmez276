package main

import "time"

// runIntro displays the intro screen and waits for button A
func runIntro() {
	drawIntroScreen()
	var last ButtonState
	for {
		btns := readButtons()
		if btns.APressed && !last.APressed {
			return
		}
		last = btns
		time.Sleep(50 * time.Millisecond)
	}
}

// drawIntroScreen draws the game title and instructions
func drawIntroScreen() {
	display.FillScreen(white)
	drawTextCenteredOnScreen(72, gameTitle, gopherBlue)
	drawTextCenteredOnScreen(98, "powered by TinyGo", black)
	drawTextCenteredOnScreen(120, "by Donia Chaiehloudj", black)
	drawTextCenteredOnScreen(200, "Press A to start", lightGray)
}
