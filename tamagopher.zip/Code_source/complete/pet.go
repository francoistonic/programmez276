package main

import (
	"time"
)

type Pet struct {
	Name  string
	Stage LifeStage

	// Core stats (0-100)
	Hunger    int
	Happiness int
	Health    int
	Coding    int // skill / focus (ex-discipline Tamagotchi)

	// Other state
	PoopCount int
	IsSick    bool

	// Timestamps
	BornAt     time.Time
	LastUpdate time.Time
}

type LifeStage int

const (
	StageEgg LifeStage = iota
	StageBaby
	StageChild
	StageTeen
	StageAdult
	StageElder
)

// ⏰ CUSTOMIZABLE: Tamagopher life durations
// For quick testing: use seconds (eg: 10 * time.Second)
// For normal play: use minutes (eg: 2 * time.Minute)
const (
	// Time before the egg hatches
	eggHatchDuration = 1 * time.Minute

	// Time spent in each stage (baby, child, teen, adult)
	stageStepDuration = 4 * time.Minute

	// Time spent as elder before the end
	elderStageDuration = 10 * time.Minute

	// Frequency of stat decay (hunger, happiness, coding)
	statDecayInterval = 1 * time.Minute
)

//// For normal play, uncomment these lines and comment the ones above:
//const (
//	eggHatchDuration   = 2 * time.Minute
//	stageStepDuration  = 8 * time.Minute
//	elderStageDuration = 10 * time.Minute
//	statDecayInterval  = 2 * time.Minute
//)

// NewPet creates a new Tamagopher with initial stats
func NewPet() *Pet {
	now := time.Now()
	return &Pet{
		Name:  "Gopher",
		Stage: StageEgg,

		// 🎮 CUSTOMIZABLE: Starting stats (0-100)
		// Change these values to make the game easier or harder!
		Hunger:    50,  // Higher = less hungry at start
		Happiness: 70,  // Higher = more happy
		Health:    100, // Always starts healthy
		Coding:    50,  // Coding skill

		PoopCount:  0,
		IsSick:     false,
		BornAt:     now,
		LastUpdate: now,
	}
}

// Reset restarts a new life (back to egg)
func (p *Pet) Reset() {
	now := time.Now()
	p.Stage = StageEgg
	p.Hunger = 50
	p.Happiness = 70
	p.Health = 100
	p.Coding = 50
	p.PoopCount = 0
	p.IsSick = false
	p.BornAt = now
	p.LastUpdate = now
}

// Update advances the simulation (stat decay, life stage evolution)
func (p *Pet) Update() {
	now := time.Now()
	elapsed := now.Sub(p.LastUpdate)

	if elapsed >= statDecayInterval {
		if p.Hunger > 0 {
			p.Hunger--
		}
		if p.Stage != StageEgg {
			if p.Happiness > 0 {
				p.Happiness--
			}
			if p.Coding > 0 {
				p.Coding--
			}
			if p.Hunger < 80 && p.PoopCount < 3 && (now.Unix()%90) < 15 {
				p.PoopCount++
			}
			if p.PoopCount >= 2 && p.Health < 50 && !p.IsSick && (now.Unix()%10) < 3 {
				p.IsSick = true
			}
		}
		if (p.Hunger < 15 || (p.Stage != StageEgg && p.PoopCount >= 3)) && p.Health > 0 {
			p.Health--
		}
		p.LastUpdate = now
	}

	p.updateStage()
}

// updateStage updates the life stage based on age
func (p *Pet) updateStage() {
	if next := stageAt(time.Since(p.BornAt)); next != p.Stage {
		p.Stage = next
	}
}

// IsLifeComplete returns true when the gopher's life is complete (elder stage ended)
func (p *Pet) IsLifeComplete() bool {
	return time.Since(p.BornAt) >= elderAgeStart()+elderStageDuration
}

// elderAgeStart calculates the age at which the gopher becomes elder
func elderAgeStart() time.Duration {
	return eggHatchDuration + 4*stageStepDuration
}

// stageAt determines the life stage based on elapsed age
func stageAt(age time.Duration) LifeStage {
	if age < eggHatchDuration {
		return StageEgg
	}
	age -= eggHatchDuration
	switch int(age / stageStepDuration) {
	case 0:
		return StageBaby
	case 1:
		return StageChild
	case 2:
		return StageTeen
	case 3:
		return StageAdult
	default:
		return StageElder
	}
}

// tinyfont/gophers glyphs — https://github.com/tinygo-org/tinyfont/blob/dev/images/gophers.png
// B default, D baby, E child, O egg, X teenager (guitar),  Z old.
const (
	gopherDefault = 'B'
	gopherBaby    = 'D'
	gopherChild   = 'E'
	gopherEgg     = 'O'
	gopherTeen    = 'X'
	gopherOld     = 'Z'
)

// GetGopherChar returns the character (letter) corresponding to the current life stage
func (p *Pet) GetGopherChar() rune {
	return p.stageGopherChar()
}

// StageLabel returns the name of the current life stage (egg, baby, child, etc.)
func (p *Pet) StageLabel() string {
	switch p.Stage {
	case StageEgg:
		return "egg"
	case StageBaby:
		return "baby"
	case StageChild:
		return "child"
	case StageTeen:
		return "teenager"
	case StageAdult:
		return "adult"
	case StageElder:
		return "elder"
	default:
		return "baby"
	}
}

// IsActionAllowed checks if an action is allowed for the current stage
// (for example, an egg can only feed and take medicine)
func (p *Pet) IsActionAllowed(a Action) bool {
	if a == ActionReset {
		return true
	}
	if p.Stage == StageEgg {
		return a == ActionFeed || a == ActionMed
	}
	return true
}

// stageGopherChar returns the font character corresponding to the life stage
func (p *Pet) stageGopherChar() rune {
	switch p.Stage {
	case StageEgg:
		return gopherEgg
	case StageBaby:
		return gopherBaby
	case StageChild:
		return gopherChild
	case StageTeen:
		return gopherTeen
	case StageAdult:
		return gopherDefault
	case StageElder:
		return gopherOld
	default:
		return gopherDefault
	}
}

// ====================================================================
// 🎮 Tamagopher Actions - CUSTOMIZABLE!
// Change the values (+30, +25, -3, etc.) to make the game easier
// or harder. Bigger values = stronger effect!
// ====================================================================

// Feed gives food to the gopher (increases hunger)
func (p *Pet) Feed() {
	p.Hunger = min(100, p.Hunger+30) // 🎮 CUSTOMIZABLE: +30 hunger
}

// Play plays with the gopher (increases happiness, decreases hunger, increases coding)
func (p *Pet) Play() {
	p.Happiness = min(100, p.Happiness+25) // 🎮 CUSTOMIZABLE: +25 happiness
	p.Hunger = max(0, p.Hunger-3)          // 🎮 CUSTOMIZABLE: -3 hunger (playing makes hungry!)
	p.Coding = min(100, p.Coding+3)        // 🎮 CUSTOMIZABLE: +3 coding
}

// Clean cleans the environment (removes poop, increases happiness)
func (p *Pet) Clean() {
	p.PoopCount = 0
	p.Happiness = min(100, p.Happiness+15) // 🎮 CUSTOMIZABLE: +15 happiness
}

// GiveMedicine heals the gopher when sick
func (p *Pet) GiveMedicine() {
	if p.IsSick {
		p.IsSick = false
		p.Health = min(100, p.Health+40) // 🎮 CUSTOMIZABLE: +40 health
	}
}

// DoCoding teaches coding to the gopher (increases coding, decreases happiness)
func (p *Pet) DoCoding() {
	p.Coding = min(100, p.Coding+20)    // 🎮 CUSTOMIZABLE: +20 coding
	p.Happiness = max(0, p.Happiness-3) // 🎮 CUSTOMIZABLE: -3 happiness (learning is hard!)
}

// min returns the smaller of two numbers
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// max returns the larger of two numbers
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
