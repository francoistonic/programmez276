package main

import (
	"image/color"

	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/freemono"
	"tinygo.org/x/tinyfont/notoemoji"
)

// Noto Emoji 2017 (~20 px) — limited glyphs: https://github.com/tinygo-org/tinyfont/tree/master/notoemoji
var emojiFont = &notoemoji.NotoEmojiRegular20pt

// Available glyphs: see tinyfont/notoemoji (no 🍎, 💊, 🍔 in this 2017 font).
const (
	emojiFeed  = '\u2668' // ♨ hot food
	emojiPlay  = '\u26BD' // ⚽
	emojiClean = '\u2728' // ✨
	emojiMed   = '\u26A1' // ⚡ boost / energy
	emojiCode  = '\u270F' // ✏ coding
	emojiReset = '\u21A9' // ↩
)

// 🎨 CUSTOMIZABLE: Stat bar and text colors
// Change R, G, B between 0 and 255 to create your own colors!
var (
	black     = color.RGBA{R: 0, G: 0, B: 0, A: 255}       // Black text
	lightGray = color.RGBA{R: 200, G: 200, B: 200, A: 255} // Bar background
	red       = color.RGBA{R: 255, G: 0, B: 0, A: 255}     // Red bar (stat < 30)
	green     = color.RGBA{R: 0, G: 200, B: 0, A: 255}     // Green bar (stat > 60)
	yellow    = color.RGBA{R: 255, G: 200, B: 0, A: 255}   // Yellow bar (stat 30-60)
)

// Layout constants
const (
	gameTitle = "Tamagopher"

	statsStartX = 160 // Stats column
	statsStartY = 38  // below title line
	// Each stat: icon + label, bar tight under label, then gap before the next row.
	statIconW       = 14
	statTextX       = statsStartX + statIconW + 4 // 178
	statLabelY      = 10                          // tinyfont baseline
	statLabelBarGap = 4                           // label → bar
	statBarH        = 10
	statBarW        = 100
	statAfterBarGap = 11                                                        // bar → next label (wider than statLabelBarGap)
	statRowStride   = statLabelY + statLabelBarGap + statBarH + statAfterBarGap // 35

	stageLabelX = 10 // inset from left; open space to the right before stats
	stageLabelY = 20 // inset from top
	gopherDrawX = 20
	gopherDrawY = 160

	actionRow1Y  = 186 // Feed / Play / Clean
	actionRow2Y  = 214 // Med / Coding / Reset (fits 240px tall screen with selection box)
	actionCol1X  = 14
	actionCol2X  = 114
	actionCol3X  = 214
	actionLabelX = 28 // text offset right of emoji
	emojiSlotW   = 22
	emojiSlotH   = 20

	actionSelectPadX      = 2
	actionSelectPadTop    = 10 // more room above the emoji
	actionSelectPadBottom = 3  // tight under the emoji slot
	actionSelectW         = 90
	actionSelectH         = actionSelectPadTop + emojiSlotH + actionSelectPadBottom // 33
)

// screenState captures everything drawn on screen; used to skip redundant full redraws
// by comparing the current state with the previous frame
type screenState struct {
	stage     LifeStage
	gopher    rune
	selected  Action
	hunger    int
	happiness int
	health    int
	coding    int
	allowed   uint8 // bit i set => action i is enabled (not grayed)
}

// captureScreenState takes a snapshot of all visible game state for change detection
func captureScreenState(pet *Pet, menu *ActionMenu) screenState {
	s := screenState{
		stage:    pet.Stage,
		gopher:   pet.GetGopherChar(),
		selected: menu.Selected,
		hunger:   pet.Hunger,
		health:   pet.Health,
	}
	if pet.Stage != StageEgg {
		s.happiness = pet.Happiness
		s.coding = pet.Coding
	}
	for a := Action(0); a < ActionCount; a++ {
		if pet.IsActionAllowed(a) {
			s.allowed |= 1 << a
		}
	}
	return s
}

// drawStageLabel displays the game title and current life stage at the top
func drawStageLabel(pet *Pet) {
	drawText(stageLabelX, stageLabelY, gameTitle+": "+pet.StageLabel(), black)
}

// drawStats draws all four statistics with icons and progress bars
// (Hunger, Happiness, Health, Coding - happiness and coding hidden for eggs)
func drawStats(pet *Pet) {
	y := int16(statsStartY)
	drawStatRow(y, pet.Hunger, "Hunger", drawBowlIcon)
	y += statRowStride
	if pet.Stage != StageEgg {
		drawStatRow(y, pet.Happiness, "Happy", drawHeartIcon)
		y += statRowStride
	}
	drawStatRow(y, pet.Health, "Health", drawCrossIcon)
	y += statRowStride
	if pet.Stage != StageEgg {
		drawStatRow(y, pet.Coding, "Coding", drawCodeIcon)
	}
}

// drawStatRow draws one complete stat line: icon, label text, and colored progress bar
// The icon and label are aligned, with a fixed gap before the bar below
func drawStatRow(rowY int16, value int, label string, drawIcon func(x, y int16)) {
	iconY := rowY + 1
	drawIcon(statsStartX, iconY)
	drawText(statTextX, rowY+statLabelY, label, black)
	barY := rowY + statLabelY + statLabelBarGap
	drawStatBarAt(statTextX, barY, value)
}

// drawActions draws all six action buttons in a 3x2 grid at the bottom of the screen
func drawActions(selected Action, pet *Pet) {
	drawAction(actionCol1X, actionRow1Y, emojiFeed, "Feed", selected == ActionFeed, pet.IsActionAllowed(ActionFeed))
	drawAction(actionCol2X, actionRow1Y, emojiPlay, "Play", selected == ActionPlay, pet.IsActionAllowed(ActionPlay))
	drawAction(actionCol3X, actionRow1Y, emojiClean, "Clean", selected == ActionClean, pet.IsActionAllowed(ActionClean))

	drawAction(actionCol1X, actionRow2Y, emojiMed, "Med", selected == ActionMed, pet.IsActionAllowed(ActionMed))
	drawAction(actionCol2X, actionRow2Y, emojiCode, "Coding", selected == ActionCoding, pet.IsActionAllowed(ActionCoding))
	drawAction(actionCol3X, actionRow2Y, emojiReset, "Reset", selected == ActionReset, pet.IsActionAllowed(ActionReset))
}

// drawAction draws a single action button with emoji and label
// Shows blue highlight if selected, gray if disabled
func drawAction(x, y int16, emoji rune, label string, selected, enabled bool) {
	if selected && enabled {
		display.FillRectangle(
			x-actionSelectPadX,
			y-actionSelectPadTop,
			actionSelectW,
			actionSelectH,
			gopherBlue,
		)
	}
	emojiColor := black
	if !enabled {
		emojiColor = lightGray
	}
	drawEmojiInSlot(emoji, x, y, emojiSlotW, emojiSlotH, emojiColor)
	textColor := black
	if !enabled {
		textColor = lightGray
	} else if selected {
		textColor = white
	}
	drawText(x+actionLabelX, y+5, label, textColor)
}

// drawEmojiInSlot draws an emoji character centered within a rectangular slot
func drawEmojiInSlot(r rune, sx, sy, w, h int16, c color.RGBA) {
	glyph := emojiFont.GetGlyph(r)
	info := glyph.Info()
	if info.Width == 0 && info.Height == 0 && r != 0 {
		return
	}
	_, outer := tinyfont.LineWidth(emojiFont, string(r))
	ex := sx + (w-int16(outer))/2
	ey := sy + h - 6
	tinyfont.DrawChar(&display, emojiFont, ex, ey, r, c)
}

// drawStatBarAt draws a colored progress bar based on the stat value (0-100)
func drawStatBarAt(x, barY int16, value int) {
	display.FillRectangle(x, barY, statBarW, statBarH, lightGray)
	fillWidth := int16(value) * statBarW / 100
	if fillWidth > 0 {
		display.FillRectangle(x, barY, fillWidth, statBarH, getStatColor(value))
	}
}

// getStatColor returns the bar color based on value: green (>60), yellow (30-60), red (<30)
func getStatColor(value int) color.RGBA {
	if value > 60 {
		return green
	} else if value > 30 {
		return yellow
	}
	return red
}

// drawText draws text at the specified position with the given color
func drawText(x, y int16, text string, col color.RGBA) {
	tinyfont.WriteLine(&display, &freemono.Bold9pt7b, x, y, text, col)
}

// drawTextCenteredOnScreen draws text horizontally centered on the screen at the given y position
func drawTextCenteredOnScreen(y int16, text string, col color.RGBA) {
	w, _ := tinyfont.LineWidth(&freemono.Bold9pt7b, text)
	x := (screenWidth - int16(w)) / 2
	if x < 0 {
		x = 0
	}
	drawText(x, y, text, col)
}

// drawBowlIcon draws a food bowl icon in a 12×11 px box (for Hunger stat)
func drawBowlIcon(x, y int16) {
	display.FillRectangle(x, y+8, 12, 2, black)
	display.FillRectangle(x, y+6, 2, 4, black)
	display.FillRectangle(x+10, y+6, 2, 4, black)
	display.FillRectangle(x+2, y+3, 8, 5, gopherBlue)
}

// drawHeartIcon draws a heart icon in a 12×11 px box (for Happiness stat)
func drawHeartIcon(x, y int16) {
	display.FillRectangle(x+2, y+1, 3, 3, red)
	display.FillRectangle(x+7, y+1, 3, 3, red)
	display.FillRectangle(x+1, y+3, 10, 3, red)
	display.FillRectangle(x+2, y+6, 8, 2, red)
	display.FillRectangle(x+3, y+8, 6, 1, red)
}

// drawCrossIcon draws a medical cross icon in a 12×11 px box (for Health stat)
func drawCrossIcon(x, y int16) {
	display.FillRectangle(x+4, y+1, 4, 9, green)
	display.FillRectangle(x+2, y+4, 8, 3, green)
}

// drawCodeIcon draws a laptop/screen icon in a 12×11 px box (for Coding stat)
func drawCodeIcon(x, y int16) {
	display.FillRectangle(x+2, y+1, 3, 8, yellow)
	display.FillRectangle(x+5, y+5, 3, 4, black)
	display.FillRectangle(x+7, y+8, 2, 2, black)
}
