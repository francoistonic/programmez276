package main

import "time"

// runEndScreen displays the end screen and waits for button A to restart
func runEndScreen() {
	drawEndScreen()
	var last ButtonState
	for {
		btns := readButtons()
		if btns.APressed && !last.APressed {
			return
		}
		last = btns
		time.Sleep(50 * time.Millisecond)
	}
}

// drawEndScreen draws the congratulations message and elder gopher
func drawEndScreen() {
	display.FillScreen(white)
	drawEndScreenGopher()
	drawTextCenteredOnScreen(178, "Well done!", gopherBlue)
	drawTextCenteredOnScreen(200, "Start a new tamagopher?", black)
	drawTextCenteredOnScreen(222, "Press A", lightGray)
}

// drawEndScreenGopher draws the elder gopher on the end screen
func drawEndScreenGopher() {
	glyph := gopherFont.GetGlyph(gopherOld)
	drawCharScaled(glyph, 128, 108, 2, gopherBlue)
}
