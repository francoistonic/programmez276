package main

// Action represents an action you can do with your Tamagopher
type Action int

const (
	ActionFeed   Action = iota // Feed: give food
	ActionPlay                 // Play: makes happy
	ActionClean                // Clean: removes poop
	ActionMed                  // Medicine: heals sickness
	ActionCoding               // Coding: teaches programming
	ActionReset                // Reset: start a new life
	ActionCount                // Total number of actions
)

// ActionMenu manages the action menu with the current selection
type ActionMenu struct {
	Selected Action
}

// NewActionMenu creates a new action menu
func NewActionMenu() *ActionMenu {
	return &ActionMenu{Selected: ActionFeed}
}

// MoveRight moves the selection to the right
func (m *ActionMenu) MoveRight(pet *Pet) {
	m.moveBy(pet, 1)
}

// MoveLeft moves the selection to the left
func (m *ActionMenu) MoveLeft(pet *Pet) {
	m.moveBy(pet, -1)
}

// MoveDown moves the selection down
func (m *ActionMenu) MoveDown(pet *Pet) {
	if m.Selected < ActionMed {
		m.Selected += 3
	} else {
		m.moveBy(pet, 1)
	}
	m.clampToAllowed(pet)
}

// MoveUp moves the selection up
func (m *ActionMenu) MoveUp(pet *Pet) {
	if m.Selected >= ActionMed {
		m.Selected -= 3
	} else {
		m.moveBy(pet, -1)
	}
	m.clampToAllowed(pet)
}

// EnsureSelection ensures the selected action is allowed
func (m *ActionMenu) EnsureSelection(pet *Pet) {
	m.clampToAllowed(pet)
}

// moveBy moves the selection by delta positions (skipping disallowed actions)
func (m *ActionMenu) moveBy(pet *Pet, delta int) {
	for i := 0; i < int(ActionCount); i++ {
		next := int(m.Selected) + delta
		if next < 0 {
			next += int(ActionCount)
		}
		m.Selected = Action(next % int(ActionCount))
		if pet.IsActionAllowed(m.Selected) {
			return
		}
	}
}

// clampToAllowed forces the selection to an allowed action
func (m *ActionMenu) clampToAllowed(pet *Pet) {
	if pet.IsActionAllowed(m.Selected) {
		return
	}
	m.moveBy(pet, 1)
}

// Execute performs the currently selected action
func (m *ActionMenu) Execute(pet *Pet) {
	if !pet.IsActionAllowed(m.Selected) {
		return
	}
	switch m.Selected {
	case ActionFeed:
		pet.Feed()
	case ActionPlay:
		pet.Play()
	case ActionClean:
		pet.Clean()
	case ActionMed:
		pet.GiveMedicine()
	case ActionCoding:
		pet.DoCoding()
	case ActionReset:
		pet.Reset()
		m.EnsureSelection(pet)
	default:
		panic("unhandled default case")
	}
}
