package main

import (
	"machine"
)

// Buttons holds all the button pins
type Buttons struct {
	Up    machine.Pin
	Down  machine.Pin
	Left  machine.Pin
	Right machine.Pin
	A     machine.Pin
	B     machine.Pin
}

var buttons Buttons

// initButtons configures all button pins as inputs with pull-up resistors
func initButtons() {
	buttons = Buttons{
		Up:    machine.BUTTON_UP,
		Down:  machine.BUTTON_DOWN,
		Left:  machine.BUTTON_LEFT,
		Right: machine.BUTTON_RIGHT,
		A:     machine.BUTTON_A,
		B:     machine.BUTTON_B,
	}

	buttons.Up.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	buttons.Down.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	buttons.Left.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	buttons.Right.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	buttons.A.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	buttons.B.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
}

// ButtonState tracks which buttons are currently pressed
type ButtonState struct {
	UpPressed    bool
	DownPressed  bool
	LeftPressed  bool
	RightPressed bool
	APressed     bool
	BPressed     bool
}

// readButtons reads the current state of all buttons (inverted because of pull-up)
func readButtons() ButtonState {
	return ButtonState{
		UpPressed:    !buttons.Up.Get(), // pullup inverts
		DownPressed:  !buttons.Down.Get(),
		LeftPressed:  !buttons.Left.Get(),
		RightPressed: !buttons.Right.Get(),
		APressed:     !buttons.A.Get(),
		BPressed:     !buttons.B.Get(),
	}
}
