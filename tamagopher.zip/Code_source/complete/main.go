package main

import (
	"image/color"
	"machine"
	"time"

	"tinygo.org/x/drivers/st7789"
	"tinygo.org/x/tinyfont"
	"tinygo.org/x/tinyfont/gophers"
)

const (
	screenWidth  = 320
	screenHeight = 240
	// 🎨 CUSTOMIZABLE: Gopher size (1 = small, 3 = medium, 5 = large)
	gopherScale = 3
)

var (
	display st7789.Device

	gopherFont = &gophers.Regular58pt

	// 🎨 CUSTOMIZABLE: Gopher color (Change R, G, B between 0 and 255)
	// Examples: Red {255,0,0}, Green {0,255,0}, Pink {255,105,180}
	gopherBlue = color.RGBA{R: 0, G: 173, B: 216, A: 255}

	// Background color
	white = color.RGBA{R: 255, G: 255, B: 255, A: 255}
)

// main is the main function that starts the game
func main() {
	initDisplay()
	initButtons()
	runIntro()

	pet := NewPet()
	menu := NewActionMenu()

	// Infinite loop: the game restarts after each playthrough
	for {
		runGameplay(pet, menu)
		runEndScreen()
		pet.Reset()
		menu.EnsureSelection(pet)
	}
}

// runGameplay manages the main game loop (read buttons, update stats, display)
func runGameplay(pet *Pet, menu *ActionMenu) {
	var lastButtons ButtonState
	redrawScreen(pet, menu)
	onScreen := captureScreenState(pet, menu)

	ticker := time.NewTicker(100 * time.Millisecond)
	for range ticker.C {
		if pet.IsLifeComplete() {
			return
		}

		btns := readButtons()

		if btns.LeftPressed && !lastButtons.LeftPressed {
			menu.MoveLeft(pet)
		}
		if btns.RightPressed && !lastButtons.RightPressed {
			menu.MoveRight(pet)
		}
		if btns.UpPressed && !lastButtons.UpPressed {
			menu.MoveUp(pet)
		}
		if btns.DownPressed && !lastButtons.DownPressed {
			menu.MoveDown(pet)
		}
		if btns.APressed && !lastButtons.APressed {
			menu.Execute(pet)
		}

		lastButtons = btns

		pet.Update()
		menu.EnsureSelection(pet)

		next := captureScreenState(pet, menu)
		if next != onScreen {
			redrawScreen(pet, menu)
			onScreen = next
		}
	}
}

// redrawScreen redraws the entire screen (gopher, stats, menu)
func redrawScreen(pet *Pet, menu *ActionMenu) {
	display.FillScreen(white)
	drawGopherLeft(pet.GetGopherChar(), gopherBlue)
	drawStageLabel(pet)
	drawStats(pet)
	drawActions(menu.Selected, pet)
}

// drawGopherLeft draws the gopher on the left side of the screen
func drawGopherLeft(char rune, col color.RGBA) {
	glyph := gopherFont.GetGlyph(char)

	drawCharScaled(glyph, gopherDrawX, gopherDrawY, gopherScale, col)
}

// drawCharScaled draws a scaled character (each pixel becomes a scale×scale square)
func drawCharScaled(glyph tinyfont.Glypher, x, y, scale int16, col color.RGBA) {
	g, ok := glyph.(*tinyfont.Glyph)
	if !ok || scale <= 1 {
		tinyfont.DrawChar(&display, gopherFont, x, y, glyph.Info().Rune, col)
		return
	}

	bitmapOffset := 0
	bitmap := byte(0)
	if len(g.Bitmaps) > 0 {
		bitmap = g.Bitmaps[bitmapOffset]
	}
	bit := uint8(0)
	for j := int16(0); j < int16(g.Height); j++ {
		for i := int16(0); i < int16(g.Width); i++ {
			if bitmap&0x80 != 0 {
				px := x + (int16(g.XOffset)+i)*scale
				py := y + (int16(g.YOffset)+j)*scale
				display.FillRectangle(px, py, scale, scale, col)
			}
			bitmap <<= 1
			bit++
			if bit > 7 {
				bitmapOffset++
				if bitmapOffset < len(g.Bitmaps) {
					bitmap = g.Bitmaps[bitmapOffset]
				}
				bit = 0
			}
		}
	}
}

// initDisplay initializes the Gopher Badge screen
func initDisplay() {
	machine.SPI0.Configure(machine.SPIConfig{
		Frequency: 8000000,
		Mode:      0,
	})

	display = st7789.New(machine.SPI0,
		machine.TFT_RST,       // reset
		machine.TFT_WRX,       // data/command
		machine.TFT_CS,        // chip select
		machine.TFT_BACKLIGHT, // backlight
	)

	display.Configure(st7789.Config{
		Rotation: st7789.ROTATION_270,
		Height:   320,
	})
}
