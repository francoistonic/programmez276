# tamagopher

Tamagopher is a Tamagotchi-like virtual pet game featuring a gopher character, built with TinyGo for the Gopher Badge hardware.

## Hardware

- **Board**: [Gopher Badge](https://gopherbadge.com/) (RP2040-based)
- **Display**: 320x240 IPS TFT
- **Input**: 6 buttons + accelerometer
- **Target**: `gopher-badge`

## Features (Roadmap)

Phase 1: **Display the Gopher** ✨
- Static gopher display using Gopher font

Future phases:
- Button input handling
- Gopher animations (happy, sad, eating, sleeping)
- Pet stats (hunger, happiness, health, age)
- Life simulation with stat decay over time
- Interactions (feed, play, clean, medicine)
- Buzzer alerts when attention needed

## Building

### Prerequisites

```bash
# Install TinyGo (macOS)
brew tap tinygo-org/tools
brew install tinygo
```

### IDE (Cursor / VS Code)

The `machine` package and board pins only exist in TinyGo’s target GOROOT, not in standard Go. Configure gopls once per machine:

```bash
./scripts/configure-ide.sh
```

Then reload the editor window (`Developer: Reload Window`). Optional: install the [TinyGo](https://marketplace.visualstudio.com/items?itemName=tinygo.vscode-tinygo) extension.

### Build and Flash

```bash
# Build for Gopher Badge
tinygo build -target=gopher-badge -o tamagopher.uf2 .

# Or build and flash directly
tinygo flash -target=gopher-badge
```

## Credits

- **Gopher Font**: Created by [Jaana Dogan](https://github.com/rakyll) (CC-NC License)
