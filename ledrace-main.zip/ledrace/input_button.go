//go:build !ultrasonic

// Default input: standard push button with internal pull-up.
// This file is used unless you build with -tags ultrasonic.
package main

import "machine"

// ButtonInput detects a click (press then release) on a single digital pin.
type ButtonWithLEDInput struct {
	pin        machine.Pin
	led        machine.Pin
	wasPressed bool
}

func newPlayerInput(pin machine.Pin, led machine.Pin) PlayerInput {
	pin.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	led.Configure(machine.PinConfig{Mode: machine.PinOutput})

	return &ButtonWithLEDInput{pin: pin, led: led}
}

// Clicked returns true once per press-release cycle.
// With PvinInputPullup: Get()==false means the button is physically pressed.
func (b *ButtonWithLEDInput) Clicked() bool {
	isPressed := !b.pin.Get()
	clicked := !b.wasPressed && isPressed
	b.wasPressed = isPressed
	if isPressed {
		b.led.High()
	} else {
		b.led.Low()
	}
	return clicked
}

func (b *ButtonWithLEDInput) IsActive() bool {
	return b.wasPressed
}
