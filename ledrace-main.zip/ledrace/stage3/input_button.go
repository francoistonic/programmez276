//go:build !ultrasonic

package main

import "machine"

// ButtonWithLEDInput detects a press-and-release on a digital pin and
// drives a status LED while the button is held.
type ButtonWithLEDInput struct {
	pin        machine.Pin
	led        machine.Pin
	wasPressed bool
}

func newPlayerInput(pin machine.Pin, led machine.Pin) PlayerInput {
	pin.Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	led.Configure(machine.PinConfig{Mode: machine.PinOutput})
	return &ButtonWithLEDInput{pin: pin, led: led}
}

// Clicked returns true once per press-release cycle.
// PinInputPullup: Get()==false means the button is physically pressed.
func (b *ButtonWithLEDInput) Clicked() bool {
	isPressed := !b.pin.Get()
	clicked := !b.wasPressed && isPressed
	b.wasPressed = isPressed
	if isPressed {
		b.led.High()
	} else {
		b.led.Low()
	}
	return clicked
}

func (b *ButtonWithLEDInput) IsActive() bool {
	return b.wasPressed
}
