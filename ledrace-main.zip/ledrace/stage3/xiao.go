//go:build xiao_esp32c3 || xiao_ble || xiao || xiao_rp2040
// +build xiao_esp32c3 xiao_ble xiao xiao_rp2040

package main

import (
	"machine"

	"tinygo.org/x/drivers/ws2812"
)

func configureHardware() {
	players[0].input = newPlayerInput(machine.D5, machine.D6)
	players[0].color = red

	players[1].input = newPlayerInput(machine.D8, machine.D7)
	players[1].color = green

	players[2].input = newPlayerInput(machine.D1, machine.D2)
	players[2].color = yellow

	players[3].input = newPlayerInput(machine.D3, machine.D4)
	players[3].color = blue

	neo := machine.D10
	neo.Configure(machine.PinConfig{Mode: machine.PinOutput})
	track.ws = ws2812.New(neo)
}
