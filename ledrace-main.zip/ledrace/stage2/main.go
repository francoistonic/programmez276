package main

import (
	"image/color"
	"machine"
	"time"

	"tinygo.org/x/drivers/ws2812"
)

const TRACK_LEN = 300
const PLAYERS = 4

func main() {
	neo := machine.D10
	neo.Configure(machine.PinConfig{Mode: machine.PinOutput})
	strip := ws2812.New(neo)
	leds := make([]color.RGBA, TRACK_LEN)

	// One button per player, connected between the pin and GND.
	// PinInputPullup holds the pin HIGH; pressing pulls it LOW.
	buttons := [PLAYERS]machine.Pin{machine.D5, machine.D8, machine.D1, machine.D3}
	for i := range buttons {
		buttons[i].Configure(machine.PinConfig{Mode: machine.PinInputPullup})
	}

	colors := [PLAYERS]color.RGBA{
		{255, 0, 0, 255},
		{0, 255, 0, 255},
		{255, 255, 0, 255},
		{0, 0, 255, 255},
	}
	// Each player owns a 3-LED marker spread evenly across the strip
	home := [PLAYERS]int{0, 75, 150, 225}

	for {
		for i := range leds {
			leds[i] = color.RGBA{}
		}
		for p := 0; p < PLAYERS; p++ {
			if !buttons[p].Get() { // LOW == pressed
				for d := 0; d < 3; d++ {
					leds[(home[p]+d)%TRACK_LEN] = colors[p]
				}
			}
		}
		strip.WriteColors(leds)
		time.Sleep(10 * time.Millisecond)
	}
}
