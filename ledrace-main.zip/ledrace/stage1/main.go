package main

import (
	"image/color"
	"machine"
	"time"

	"tinygo.org/x/drivers/ws2812"
)

const TRACK_LEN = 300

func main() {
	neo := machine.D10
	neo.Configure(machine.PinConfig{Mode: machine.PinOutput})
	strip := ws2812.New(neo)

	leds := make([]color.RGBA, TRACK_LEN)

	// Flood the whole strip in red, then green, then blue
	for _, c := range []color.RGBA{
		{50, 0, 0, 255},
		{0, 50, 0, 255},
		{0, 0, 50, 255},
	} {
		for i := range leds {
			leds[i] = c
		}
		strip.WriteColors(leds)
		time.Sleep(1 * time.Second)
	}

	// Clear the strip
	for i := range leds {
		leds[i] = color.RGBA{}
	}

	// Chasing dot cycling through the four player colours
	playerColors := [4]color.RGBA{
		{255, 0, 0, 255},
		{0, 255, 0, 255},
		{255, 255, 0, 255},
		{0, 0, 255, 255},
	}
	pos := 0
	lap := 0
	for {
		leds[pos] = color.RGBA{}
		pos = (pos + 1) % TRACK_LEN
		if pos == 0 {
			lap++
		}
		leds[pos] = playerColors[lap%4]
		strip.WriteColors(leds)
		time.Sleep(16 * time.Millisecond)
	}
}
