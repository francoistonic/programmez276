# Memory Index

- [LED Race project context](project_ledrace.md) — Hardware (XIAO ESP32C3), stage structure, article goals, WiFi deferred
