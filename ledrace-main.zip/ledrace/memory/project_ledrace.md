---
name: LED Race project context
description: Open LED Race project goals, hardware target, article format, and stage structure
type: project
---

TinyGo implementation of Open LED Race targeting Seeed Studio XIAO ESP32C3 (chosen for WiFi capability to be added later).

**Why:** Educational article for a youth electronics/maker magazine, presented as a "weekend project".

**How to apply:** Keep the codebase clean, educational, and well-commented. WiFi stage is intentionally deferred — do not add it until the user asks.

## Article format
- English language
- Progressive stages from simple to complete
- Each stage is a standalone flashable TinyGo program

## Stage structure
| Stage | Goal |
|-------|------|
| stage1/ | Hello LED Strip — WS2812 basics, color channels, chase animation |
| stage2/ | Single-player race — button input, speed/friction physics, lap counting |
| stage3/ | Two-player race — Player struct, multiple inputs, winner detection |
| stage4/ | Full 4-player game — ramps/gravity, buzzer melodies, demo mode, build-tag alternative inputs |

## Build targets
```
tinygo flash -target xiao-esp32c3 ./stage1
tinygo flash -target xiao-esp32c3 ./stage2
tinygo flash -target xiao-esp32c3 ./stage3
tinygo flash -target xiao-esp32c3 ./stage4              # default: buttons
tinygo flash -target xiao-esp32c3 -tags ultrasonic ./stage4  # HC-SR04 sensors
```

## Key decisions
- `tinygo.org/x/drivers v0.35.0` (latest as of 2026-05)
- Alternative inputs use Go build tags (`//go:build ultrasonic` vs `//go:build !ultrasonic`)
- PlayerInput interface in stage4 allows swapping input devices without touching game logic
- WiFi (espradio) deferred to a future step — user asked to skip for now
- No serial debug output — known XIAO ESP32C3 TinyGo issue

## Pins (XIAO ESP32C3)
- D6  (GPIO21): WS2812 data
- D0/A0 (GPIO2): Buzzer (strapping pin, output only)
- D10 (GPIO10): Player 1 button
- D9  (GPIO9):  Player 1 LED (strapping pin, output only)
- D8  (GPIO8):  Player 2 button (strapping pin, input pull-up)
- D7  (GPIO20): Player 2 LED
- D5  (GPIO7):  Player 3 button
- D4  (GPIO6):  Player 3 LED
- D3  (GPIO5):  Player 4 button
- D2  (GPIO4):  Player 4 LED
- D1  (GPIO3):  free
