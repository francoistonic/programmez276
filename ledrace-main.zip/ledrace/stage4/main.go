package main

import (
	"image/color"
	"time"

	"tinygo.org/x/drivers/buzzer"
	"tinygo.org/x/drivers/ws2812"
)

const ACCELERATION = 0.2
const TRACK_LEN = 300
const FRICTION = 0.015
const GRAVITY = 0.003

const PLAYERS = 4
const LAPS = 3

type Track struct {
	gravity []uint8
	leds    []color.RGBA
	ws      ws2812.Device
}

type Player struct {
	input    PlayerInput
	color    color.RGBA
	speed    float32
	position float32
	laps     uint8
}

// PlayerInput is the interface any input device must satisfy.
type PlayerInput interface {
	Clicked() bool
	IsActive() bool
}

var players [PLAYERS]Player
var track Track
var bzr buzzer.Device
var idleTime time.Time
var activity bool

var black = color.RGBA{}
var red = color.RGBA{255, 0, 0, 255}
var green = color.RGBA{0, 255, 0, 255}
var yellow = color.RGBA{255, 255, 0, 255}
var blue = color.RGBA{0, 0, 255, 255}

func main() {
	configureHardware()

	track.leds = make([]color.RGBA, TRACK_LEN)
	track.gravity = make([]uint8, TRACK_LEN)
	for i := range track.gravity {
		track.gravity[i] = 127
	}
	track.setRamp(12, 90, 100, 110)

	// Hold player 0's button at power-on to preview ramp positions
	if !players[0].input.IsActive() {
		track.showGravity()
	}

	startRace()

	for {
		activity = false
		for p := uint8(0); p < PLAYERS; p++ {
			clicked := players[p].input.Clicked()
			activity = activity || clicked

			if clicked {
				players[p].speed += ACCELERATION
			}

			// Gravity: 127 = flat, <127 = uphill, >127 = downhill
			grav := track.gravity[uint16(players[p].position)%TRACK_LEN]
			if grav < 127 {
				players[p].speed -= GRAVITY * float32(127-grav)
			} else if grav > 127 {
				players[p].speed += GRAVITY * float32(grav-127)
			}

			// Friction bleeds off speed every tick
			players[p].speed -= players[p].speed * FRICTION
			players[p].position += players[p].speed

			if players[p].position > TRACK_LEN*float32(players[p].laps) {
				players[p].laps++
			}
		}

		track.paintTrack()

		maxPos := players[0].position
		winner := uint8(0)
		for p := uint8(1); p < PLAYERS; p++ {
			if players[p].position > maxPos {
				maxPos = players[p].position
				winner = p
			}
		}
		if maxPos > LAPS*TRACK_LEN {
			time.Sleep(1500 * time.Millisecond)
			finishRace(winner)
		}

		if activity {
			idleTime = time.Now()
		} else if time.Since(idleTime) > 30*time.Second {
			idleRace()
		}

		time.Sleep(10 * time.Millisecond)
	}
}

func (t *Track) paintTrack() {
	for i := range t.leds {
		t.leds[i] = black
	}
	for p := uint8(0); p < PLAYERS; p++ {
		for l := uint8(0); l < players[p].laps; l++ {
			t.leds[(uint32(players[p].position)-uint32(l))%TRACK_LEN] = players[p].color
		}
	}
	t.ws.WriteColors(t.leds)
}

func startRace() {
	resetPlayers()
	idleTime = time.Now()

	time.Sleep(2 * time.Second)
	for i := range track.leds {
		track.leds[i] = black
	}
	track.ws.WriteColors(track.leds)
	time.Sleep(1 * time.Second)

	// Countdown: red → yellow → green, each with a buzzer tone
	track.leds[12] = red
	track.leds[11] = red
	track.ws.WriteColors(track.leds)
	bzr.Tone(buzzer.E4, buzzer.Quarter)
	time.Sleep(400 * time.Millisecond)

	track.leds[12] = black
	track.leds[11] = black
	track.leds[10] = yellow
	track.leds[9] = yellow
	track.ws.WriteColors(track.leds)
	bzr.Tone(buzzer.E4, buzzer.Quarter)
	time.Sleep(400 * time.Millisecond)

	track.leds[10] = black
	track.leds[9] = black
	track.leds[8] = green
	track.leds[7] = green
	track.ws.WriteColors(track.leds)
	bzr.Tone(buzzer.B4, buzzer.Quarter)
	time.Sleep(400 * time.Millisecond)
}

func finishRace(winner uint8) {
	resetPlayers()
	for k := 0; k < 6; k++ {
		for i := range track.leds {
			track.leds[i] = players[winner].color
		}
		track.ws.WriteColors(track.leds)
		time.Sleep(300 * time.Millisecond)
		if k == 1 {
			bzr.Tone(buzzer.C4, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.C4, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.C4, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.C4, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.G3, 0.5)
			time.Sleep(200 * time.Millisecond)
			bzr.Tone(buzzer.A3, 0.5)
			time.Sleep(200 * time.Millisecond)
			bzr.Tone(buzzer.C4, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.A3, 0.25)
			time.Sleep(100 * time.Millisecond)
			bzr.Tone(buzzer.C4, 0.5)
			time.Sleep(100 * time.Millisecond)
		}
		for i := range track.leds {
			track.leds[i] = black
		}
		track.ws.WriteColors(track.leds)
		time.Sleep(300 * time.Millisecond)
	}
	startRace()
}

func resetPlayers() {
	for p := range players {
		players[p].speed = 0
		players[p].position = 0
		players[p].laps = 0
	}
}

func idleRace() {
	var k uint16
	activity = false
	for {
		for i := 0; i < TRACK_LEN; i++ {
			track.leds[i] = rainbowRGB(uint8((i*256)/TRACK_LEN) + uint8(k))
		}
		track.ws.WriteColors(track.leds)
		k = (k + 1) % 255
		for p := uint8(0); p < PLAYERS; p++ {
			if players[p].input.Clicked() {
				activity = true
				break
			}
		}
		if activity {
			break
		}
		time.Sleep(16 * time.Millisecond)
	}
	startRace()
}

func rainbowRGB(i uint8) color.RGBA {
	if i < 85 {
		return color.RGBA{i * 3, 255 - i*3, 0, 255}
	} else if i < 170 {
		i -= 85
		return color.RGBA{255 - i*3, 0, i * 3, 255}
	}
	i -= 170
	return color.RGBA{0, i * 3, 255 - i*3, 255}
}

func (t *Track) setRamp(height uint8, start, middle, end uint32) {
	for i := uint32(0); i < middle-start; i++ {
		t.gravity[start+i] = uint8(127 - float32(i)*float32(height)/float32(middle-start))
	}
	t.gravity[middle] = 127
	for i := uint32(0); i < end-middle; i++ {
		t.gravity[middle+i+1] = uint8(127 + float32(height)*(1-float32(i)/float32(middle-start)))
	}
}

func (t *Track) showGravity() {
	for i := 0; i < TRACK_LEN; i++ {
		grav := t.gravity[i]
		r := uint8(2)
		g := uint8(2)
		if grav < 127 {
			r = 2 * (127 - grav)
		} else if grav > 127 {
			g = (grav - 127) * 2
		}
		t.leds[i] = color.RGBA{r, g, 0, 255}
	}
	t.ws.WriteColors(t.leds)
	longpress := 0
	for {
		if !players[0].input.IsActive() {
			longpress++
			if longpress > 20 {
				break
			}
		} else {
			longpress = 0
		}
		time.Sleep(100 * time.Millisecond)
	}
	time.Sleep(2 * time.Second)
}
