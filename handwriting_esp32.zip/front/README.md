# Frontend — Commande manuscrite → ESP32

Interface web de démonstration : capture caméra dans le navigateur, envoi d’une image (JPEG base64) au backend FastAPI, puis affichage du texte OCR et du JSON interprété.

## Configuration
Par défaut, le front envoie la requête au backend:

- `http://localhost:8000/api/command`

Cette URL est définie dans `index.html` dans l’appel `fetch(...)`.

## Lancer le frontend
Le plus simple et le plus fiable est d’utiliser un petit serveur statique.
