# Backend (FastAPI) — Utilisation

Ce backend reçoit une image (base64) depuis le front, exécute un prétraitement OpenCV + OCR (EasyOCR), interprète la commande via un LLM (OpenRouter) en JSON, puis envoie ce JSON à l’ESP32 sur `/command`.

## Prérequis
- Python 3.10+
- Accès Internet (pour l’appel OpenRouter)
- ESP32 connecté au même réseau local que le PC

## Installation

Se placer dans le dossier `backend/` puis :

```bash
python -m venv .venv
# Windows:
# .venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
