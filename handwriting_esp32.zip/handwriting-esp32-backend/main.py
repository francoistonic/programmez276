"""
Project: Papier → Caméra → OCR → LLM → ESP32
File: main.py
Author: Aziz Malloul
Copyright (c) 2026 Aziz Malloul
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import os
import json
import base64
import io
import re
import time
import requests
from dotenv import load_dotenv

import numpy as np
import cv2
from PIL import Image

import easyocr


# =================================================
# 0 SETTINGS
# =================================================

# Debug image saving
SAVE_DEBUG_IMAGES = False
DEBUG_DIR = os.path.join(os.path.dirname(__file__), "debug_ocr")

# ESP32 endpoint
ESP32_URL = "http://xx.xxx.xx.xx/command"

# EasyOCR (FR + EN, CPU)
easyocr_reader = easyocr.Reader(["fr", "en"], gpu=False)

# OpenRouter API key selection
load_dotenv()

ACTIVE_KEY = 2  
OPENROUTER_API_KEY = os.getenv(f"OPENROUTER_API_KEY_{ACTIVE_KEY}")

print(f"OpenRouter ACTIVE_KEY = {ACTIVE_KEY} | key loaded = {bool(OPENROUTER_API_KEY)}")



# =================================================
# 1) FASTAPI MODELS
# =================================================

class CommandRequest(BaseModel):
    image_base64: str


class CommandResponse(BaseModel):
    recognized_text: str
    command_json: dict
    sent_to_esp32: bool


# =================================================
# 2 FASTAPI APP + CORS
# =================================================

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"status": "ok"}


# =================================================
# 3 UTILS (DEBUG + GEOMETRY)
# =================================================

def ensure_debug_dir():
    if SAVE_DEBUG_IMAGES:
        os.makedirs(DEBUG_DIR, exist_ok=True)

def save_debug(name: str, img: np.ndarray):
    if not SAVE_DEBUG_IMAGES:
        return
    ensure_debug_dir()
    path = os.path.join(DEBUG_DIR, name)
    cv2.imwrite(path, img)

def order_points(pts: np.ndarray) -> np.ndarray:
    """Order 4 points: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # top-left
    rect[2] = pts[np.argmax(s)]  # bottom-right

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # top-right
    rect[3] = pts[np.argmax(diff)]  # bottom-left
    return rect

def four_point_warp(image: np.ndarray, pts: np.ndarray) -> np.ndarray:
    rect = order_points(pts.astype("float32"))
    (tl, tr, br, bl) = rect

    widthA = np.linalg.norm(br - bl)
    widthB = np.linalg.norm(tr - tl)
    maxW = int(max(widthA, widthB))

    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxH = int(max(heightA, heightB))

    # éviter les warps invalides
    maxW = max(maxW, 200)
    maxH = max(maxH, 200)

    dst = np.array([
        [0, 0],
        [maxW - 1, 0],
        [maxW - 1, maxH - 1],
        [0, maxH - 1]
    ], dtype="float32")

    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (maxW, maxH))
    return warped


# =================================================
# 4 PAPER DETECTION + OCR PREPROCESS
# =================================================

def detect_and_warp_paper(bgr: np.ndarray) -> tuple[np.ndarray, bool]:
    """
    Tente de détecter une feuille (plus grand contour 4 côtés) et de la redresser.
    Retourne (warped_image, success).
    """
    h, w = bgr.shape[:2]

    # réduire pour detection rapide (puis on warp sur l'image originale via points *scale)
    target_w = 900
    scale = target_w / float(w) if w > target_w else 1.0
    small = cv2.resize(bgr, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)

    # edges robustes
    edges = cv2.Canny(gray, 50, 150)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)

    # contours
    cnts, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return bgr, False

    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:8]

    paper_approx = None
    for c in cnts:
        area = cv2.contourArea(c)
        if area < 0.10 * (small.shape[0] * small.shape[1]):  # évite petits contours
            continue

        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)

        if len(approx) == 4:
            paper_approx = approx.reshape(4, 2)
            break

    if paper_approx is None:
        return bgr, False

    # remettre à l'échelle points vers image originale
    paper_pts = (paper_approx / scale).astype("float32")
    warped = four_point_warp(bgr, paper_pts)
    return warped, True


def preprocess_for_handwriting(bgr: np.ndarray) -> np.ndarray:
    """
    Prétraitement "scan-like" pour manuscrit:
    - gris
    - CLAHE (contraste)
    - sharpen léger
    - adaptive threshold
    - nettoyage morphologique
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    # contraste local
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    # agrandir mais PAS toujours 2.5x (sinon c'est trop lent)
    h, w = gray.shape[:2]
    if max(h, w) < 900:
        gray = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    else:
        gray = cv2.resize(gray, None, fx=1.2, fy=1.2, interpolation=cv2.INTER_AREA)


    # sharpen léger (unsharp mask)
    blur = cv2.GaussianBlur(gray, (0, 0), 1.0)
    sharp = cv2.addWeighted(gray, 1.6, blur, -0.6, 0)

    # adaptive threshold (souvent mieux que Otsu en lumière non uniforme)
    th = cv2.adaptiveThreshold(
        sharp, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,  # blockSize
        9    # C
    )

    # Nettoyage: fermeture pour renforcer traits, puis légère ouverture pour bruit
    kernel = np.ones((3, 3), np.uint8)
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel, iterations=1)
    th = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=1)

    return th


def ocr_image_from_base64(image_base64: str) -> str:
    """
    Pipeline OCR améliorée:
    - decode base64
    - detect feuille + redressement (perspective)
    - preprocess manuscrit
    - EasyOCR réglé pour mieux "deviner"
    - sauvegarde debug: frame / warped / thresh
    """
    try:
        if image_base64.startswith("data:image"):
            image_base64 = image_base64.split(",", 1)[1]

        img_bytes = base64.b64decode(image_base64)
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        bgr = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        ts = int(time.time() * 1000)
        save_debug(f"{ts}_frame.jpg", bgr)

        warped, ok = detect_and_warp_paper(bgr)
        save_debug(f"{ts}_warped_{'ok' if ok else 'fail'}.jpg", warped)

        th = preprocess_for_handwriting(warped)
        save_debug(f"{ts}_thresh.png", th)

        # limiter la taille du thresh (sinon EasyOCR devient trop lent)
        max_w = 1000
        h2, w2 = th.shape[:2]
        if w2 > max_w:
            scale = max_w / float(w2)
            th = cv2.resize(th, (max_w, int(h2 * scale)), interpolation=cv2.INTER_AREA)


        # EasyOCR attend RGB
        th_rgb = cv2.cvtColor(th, cv2.COLOR_GRAY2RGB)

        # Réglages plus tolérants pour manuscrit / contraste variable
        result = easyocr_reader.readtext(
            th_rgb,
            detail=0,
            paragraph=True,
            decoder="beamsearch",
            text_threshold=0.3,
            low_text=0.2,
            contrast_ths=0.05,
            adjust_contrast=0.1,
        )


        text = " ".join(result).strip()
        print("Texte EasyOCR :", repr(text))
        return text

    except Exception as e:
        print("Erreur OCR :", e)
        return ""


# =================================================
# 5 CLEAN OCR TEXT + LLM (OpenRouter rotation)
# =================================================

def clean_ocr_text(text: str) -> str:
    if not text:
        return ""
    t = text.lower()

    # corrections chiffres - lettres
    t = t.replace("1", "l").replace("0", "o").replace("5", "s").replace("7", "t")

    # séparateurs
    for ch in ["|", ":", ";", "'", '"', "`"]:
        t = t.replace(ch, " ")

    t = re.sub(r"[^a-z0-9éèêàùç\s]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def unknown_command():
    return {
        "actions": [
            {
                "type": "display_text",
                "colors": None,
                "state": None,
                "duration_s": None,
                "delay_ms": None,
                "blink_period_ms": None,
                "message": "Commande inconnue",
            }
        ]
    }



def interpret_with_llm(raw_text: str) -> dict:
    cleaned = clean_ocr_text(raw_text)

    print("Texte OCR brut   :", repr(raw_text))
    print("Texte OCR nettoyé:", repr(cleaned))

    if not cleaned:
        return unknown_command()

    if not OPENROUTER_API_KEY:
        print(f"OPENROUTER_API_KEY_{ACTIVE_KEY} introuvable dans le .env")
        return unknown_command()


    url = "https://openrouter.ai/api/v1/chat/completions"

    system_prompt = """
Tu transforms des phrases FR/EN venant d'un OCR BRUITÉ (manuscrit) en JSON pour un ESP32.
Tu réponds STRICTEMENT en JSON valide, sans aucun texte avant ni après.

TU DOIS TOUJOURS retourner UN SEUL objet JSON de la forme :

{
  "actions": [
    {
      "type": "set_led" | "display_text",
      "colors": ["red","green","blue"] | null,
      "state": "on" | "off" | "blink" | null,
      "duration_s": number | null,
      "delay_ms": number | null,
      "blink_period_ms": number | null,
      "message": string | null
    },
    ...
  ]
}

### Règles générales

- Découpe la phrase en actions logiques (souvent séparées par "et", ",", "puis", "ensuite"...).
- Pour CHAQUE action, ajoute un objet dans le tableau "actions".
- Tous les champs non utilisés dans une action doivent être `null`.

### LEDS (type = "set_led")

1 Détection des couleurs
- "toutes les leds", "tous les voyants" → colors = ["red","green","blue"]
- "rouge et bleu" → colors = ["red","blue"]
- "rouge et verte" → ["red","green"]
- "bleue et verte" → ["blue","green"]
- Une seule couleur → tableau avec UNE seule chaîne, ex: ["red"].
- Si on dit "éteins toutes les leds" → colors = ["red","green","blue"].

2 État de la LED
- Mots comme "allume", "allumer", "on", "active" → state = "on"
- Mots comme "éteins", "eteindre", "off", "désactive" → state = "off"
- Mots comme "clignote", "clignotant", "clignotent", "blink", "flash" → state = "blink"

3 Durée et délai
- "pendant X secondes" → duration_s = X
- "pendant X s", "pendant X sec", "pendant X sec." → duration_s = X
- "pendant X minutes" → duration_s = 60 * X
- Si "pendant" n'est pas mentionné → duration_s = null (durée infinie).
- "dans X secondes", "dans X s", "après X secondes", "après X s" → delay_ms = X * 1000
- Si aucun délai n'est mentionné → delay_ms = null.

4 Clignotement (state = "blink")
- Si on dit juste "clignote" sans précision → blink_period_ms = 500
- "toutes les 2 secondes", "tous les 2 s" → blink_period_ms = 2000
- "clignote vite" → blink_period_ms = 250
- "clignote lentement" → blink_period_ms = 1000
- Si un nombre de millisecondes est mentionné ("tous les 300 ms") → blink_period_ms = ce nombre.
- Si aucune info → blink_period_ms = 500 par défaut.

5 Exemples LED
- "allume la led rouge et bleue pendant 10 secondes"
  → actions: [
      {
        "type": "set_led",
        "colors": ["red","blue"],
        "state": "on",
        "duration_s": 10,
        "delay_ms": null,
        "blink_period_ms": null,
        "message": null
      }
    ]

- "fait clignoter la led verte pendant 30 secondes"
  → state = "blink", colors=["green"], duration_s=30, blink_period_ms=500.

- "éteins toutes les leds"
  → colors=["red","green","blue"], state="off", duration_s=null, delay_ms=null.

### TEXTE (type = "display_text")

1) Affichage d'un texte donné par l'utilisateur
- Si la phrase contient "affiche", "écris", "display" suivi d'un contenu,
  alors on affiche EXACTEMENT ce contenu.
  Ex: "affiche BONJOUR" → message = "BONJOUR"
  Ex: "écris test sur l'écran" → message = "test sur l'écran"
  EX: "affiche AZIZ MALLOUL" → message = "AZIZ MALLOUL"
  
2) Raconter / générer un contenu
- "raconte une blague", "dis une blague", "fais une blague"
  → type = "display_text"
  → message = une VRAIE petite blague courte et gentille (pas le texte "raconte une blague").
- "raconte une histoire", "raconte quelque chose de drôle"
  → message = une courte phrase adaptée à la demande.

3) Champs pour display_text
- type = "display_text"
- colors = null
- state = null
- duration_s = null
- delay_ms = null
- blink_period_ms = null
- message = texte à afficher.

4) Exemple mixte LED + texte
- "allume la led rouge et bleue pendant 50 secondes, clignote la led verte 30 secondes, raconte une blague"
  → actions: [
      {
        "type": "set_led",
        "colors": ["red","blue"],
        "state": "on",
        "duration_s": 50,
        "delay_ms": null,
        "blink_period_ms": null,
        "message": null
      },
      {
        "type": "set_led",
        "colors": ["green"],
        "state": "blink",
        "duration_s": 30,
        "delay_ms": null,
        "blink_period_ms": 500,
        "message": null
      },
      {
        "type": "display_text",
        "colors": null,
        "state": null,
        "duration_s": null,
        "delay_ms": null,
        "blink_period_ms": null,
        "message": "<une courte blague ici>"
      }
    ]

### Cas incompréhensible

Si la phrase est vraiment incompréhensible ou ne concerne ni les LEDs ni l'affichage de texte,
retourne exactement :

{
  "actions": [
    {
      "type": "display_text",
      "colors": null,
      "state": null,
      "duration_s": null,
      "delay_ms": null,
      "blink_period_ms": null,
      "message": "Commande inconnue"
    }
  ]
}
"""



    user_prompt = f"""
Texte OCR brut : "{raw_text}"
Texte nettoyé : "{cleaned}"

Basé surtout sur le texte NETTOYÉ, devine la commande la plus probable.
Répond UNIQUEMENT le JSON.
"""

# =================================================
# Supported / tested models:
# - liquid/lfm-2.5-1.2b-instruct:free
# - openai/gpt-oss-20b:free
# =================================================
    payload = {
        "model": "openai/gpt-oss-20b:free",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.0,
    }

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://handwriting-esp32-demo.local",
        "X-Title": "Handwriting ESP32 Backend",
    }

    try:
        print(f"OpenRouter avec ACTIVE_KEY={ACTIVE_KEY}")
        resp = requests.post(url, headers=headers, json=payload, timeout=8)


        if resp.status_code == 429:
            print("Quota dépassé (429) sur cette clé")
            return unknown_command()

        resp.raise_for_status()

        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        print("Réponse LLM :", content)
        return json.loads(content)

    except requests.exceptions.RequestException as e:
        print("Erreur réseau OpenRouter :", e)
        return unknown_command()
    except json.JSONDecodeError:
        print("JSON invalide retourné par OpenRouter")
        return unknown_command()


# =================================================
# 6 ENDPOINT: IMAGE -> OCR -> LLM -> ESP32
# =================================================

@app.post("/api/command", response_model=CommandResponse)
def handle_command(req: CommandRequest):

    t0 = time.time()

    recognized_text = ocr_image_from_base64(req.image_base64)
    t1 = time.time()
    print(f"OCR: {(t1 - t0):.2f}s")

    if not recognized_text.strip():
        cmd = unknown_command()
        return CommandResponse(recognized_text="", command_json=cmd, sent_to_esp32=False)

    command_json = interpret_with_llm(recognized_text)
    t2 = time.time()
    print(f"LLM: {(t2 - t1):.2f}s (total {(t2 - t0):.2f}s)")
    print("JSON de commande :", command_json)

    sent_to_esp32 = False
    try:
        actions = command_json.get("actions") or []
        if actions:
            resp = requests.post(ESP32_URL, json=command_json, timeout=5)
            resp.raise_for_status()
            sent_to_esp32 = True
            print("Commande envoyé à l'ESP32, réponse :", resp.text)
        else:
            print("Pas d'actions → rien envoyé à l'ESP32")

    except Exception as e:
        print("Erreur lors de l'envoi à l'ESP32 :", e)

    t3 = time.time()
    print(f"ESP32: {(t3 - t2):.2f}s (total {(t3 - t0):.2f}s)")

    return CommandResponse(
        recognized_text=recognized_text,
        command_json=command_json,
        sent_to_esp32=sent_to_esp32,
    )
