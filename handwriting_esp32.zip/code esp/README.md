# ESP32 — Serveur HTTP /command + LEDs + écran TFT (ILI9341)

Firmware ESP32 (Arduino) : expose un endpoint HTTP `POST /command`, reçoit un JSON d’actions, pilote 3 LEDs (R/G/B) et affiche un retour sur un écran TFT (cercles + message).

## 1 Prérequis

### Matériel
- ESP32 Dev Module
- Écran TFT SPI (ILI9341) + câblage SPI
- 3 LEDs (rouge, verte, bleue) + résistances (220–330 Ω)
- Breadboard + fils

### Logiciel
- Arduino IDE
- ESP32 core installé dans Arduino IDE
- Librairies Arduino :
  - ArduinoJson
  - TFT_eSPI


## 2 Câblage

### LEDs (exemple du projet)
- Rouge : GPIO 25 → résistance → anode LED ; cathode → GND  
- Vert  : GPIO 26 → résistance → anode LED ; cathode → GND  
- Bleu  : GPIO 27 → résistance → anode LED ; cathode → GND  

Important : GND commun entre ESP32, TFT et LEDs.

### TFT SPI
- MOSI : GPIO 23  
- SCLK : GPIO 18  
- MISO : GPIO 19 (optionnel selon module)  
- CS / DC / RST : selon module (doivent correspondre à la config TFT_eSPI)  
- Backlight : GPIO 32 ou 3.3V (selon module)

## 3 Configuration TFT_eSPI

Dans la librairie TFT_eSPI, modifier `User_Setup.h` :

- Driver :
  - `#define ILI9341_DRIVER`
- Pins (exemples, à adapter) :
  - `TFT_MOSI 23`
  - `TFT_SCLK 18`
  - `TFT_MISO 19` (si utilisé)
  - `TFT_CS 15`
  - `TFT_DC 2`
  - `TFT_RST 4`
- Fréquence SPI :
  - `#define SPI_FREQUENCY 27000000`  (27 MHz)

## 4 Configuration Wi-Fi

Dans le fichier `.ino`, modifier :

- `WIFI_SSID`
- `WIFI_PASSWORD`

## 5 Compilation / Upload

1) Ouvrir le fichier `.ino` dans Arduino IDE  
2) Board : choisir ESP32 Dev Module (ou équivalent)  
3) Port : sélectionner le port série correspondant  
4) Compiler puis Upload 

Au boot :
- le TFT affiche Boot ESP32… puis l’état Wi-Fi
- si connexion OK, l’IP s’affiche sur le TFT
- le serveur HTTP démarre sur le port 80

## 6 API HTTP

### Endpoint
- `POST http://<IP_ESP32>/command`

### Réponse
- `{"status":"ok"}` si la commande est acceptée

### Format JSON attendu
```json
{
  "actions": [
    {
      "type": "set_led" | "display_text",
      "colors": ["red","green","blue"] | [],
      "state": "on" | "off" | "blink" | null,
      "duration_s": number | null,
      "delay_ms": number | null,
      "blink_period_ms": number | null,
      "message": string | null
    }
  ]
}
