/*
  Project: Papier → Caméra → OCR → LLM → ESP32
  File: esp32_command_server.ino
  Author: Aziz Malloul
  Copyright (c) 2026 Aziz Malloul

*/

#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <TFT_eSPI.h>   // Requires TFT_eSPI User_Setup.h configuration

// Wi-Fi configuration
const char* WIFI_SSID     = "Aziz";       
const char* WIFI_PASSWORD = "aziz1";

// LED GPIO pins
const int LED_R = 25;
const int LED_G = 26;
const int LED_B = 27;

int colorToIndex(const String& c) {
  if (c == "red")   return 0;
  if (c == "green") return 1;
  if (c == "blue")  return 2;
  return -1; // Unknown color
}

int indexToPin(int idx) {
  if (idx == 0) return LED_R;
  if (idx == 1) return LED_G;
  if (idx == 2) return LED_B;
  return -1;
}

// TFT display
TFT_eSPI tft = TFT_eSPI();
int16_t cx, cy;  // centre de l’écran

// HTTP server
WebServer server(80);

// --- États pour timers et clignotement ---
bool ledTimerActive[3]       = {false,false,false};
unsigned long ledOffAtMs[3]  = {0,0,0};

bool ledBlinkActive[3]       = {false,false,false};
unsigned long ledBlinkPeriodMs[3] = {500,500,500};
unsigned long ledNextToggleMs[3]  = {0,0,0};
bool ledLevel[3]             = {false,false,false};

// --- Affichage TFT ---
String tftMessage = "";            // Text displayed in the lower area
bool tftTextDirty = true;          // faut-il redessiner la zone texte ?
unsigned long lastTftRefresh = 0;  // pour ne pas redessiner trop souvent
bool bootScreenCleared = false;    // indique si on a effacé l'écran de boot

void setLedColor(const char* color, const char* state);

// Applique l'état (on/off/blink) sur UNE LED (idx = 0,1,2)
void applyLedState(int idx, const char* state, int duration_s, int blink_period_ms) {
  int pin = indexToPin(idx);
  if (pin < 0) return;

  String st = String(state);

  // Reset timers/blink state for this LED
  ledTimerActive[idx] = false;
  ledBlinkActive[idx] = false;

  if (st == "blink") {
    int period = (blink_period_ms > 0) ? blink_period_ms : 500;
    ledBlinkActive[idx]    = true;
    ledBlinkPeriodMs[idx]  = period;
    ledLevel[idx]          = true;             // Start ON
    digitalWrite(pin, HIGH);
    ledNextToggleMs[idx]   = millis() + period;

    if (duration_s > 0) {
      ledTimerActive[idx] = true;
      ledOffAtMs[idx] = millis() + (unsigned long)duration_s * 1000UL;
    }
  } else {
    bool on = (st == "on");
    digitalWrite(pin, on ? HIGH : LOW);
    ledLevel[idx] = on;

    if (on && duration_s > 0) {
      ledTimerActive[idx] = true;
      ledOffAtMs[idx] = millis() + (unsigned long)duration_s * 1000UL;
    }
  }
}

void setLedColor(const char* color, const char* state)
{
  String c = String(color);
  bool on = (String(state) == "on");

  int pin = -1;
  if (c == "red")      pin = LED_R;
  else if (c == "green") pin = LED_G;
  else if (c == "blue")  pin = LED_B;

  if (pin < 0) return;        // couleur inconnue, on ne fait rien

  digitalWrite(pin, on ? HIGH : LOW);
}

// Dessine l'état complet de l'écran en fonction des LEDs + tftMessage
void drawTftStatus() {
  // ---------- Ligne des 3 cercles en haut ----------
  int centerY = 70;        // hauteur de la rangée de cercles
  int radius  = 50;        // rayon des cercles
  int spacing = 150;        // espace horizontal entre cercles
  int startX  = 80;        // position X du premier cercle

  for (int idx = 0; idx < 3; idx++) {
    int x = startX + idx * spacing;
    int pin = indexToPin(idx);
    if (pin < 0) continue;

    // Couleur ON pour cette LED
    uint16_t colOn;
    if (idx == 0)      colOn = TFT_RED;
    else if (idx == 1) colOn = TFT_GREEN;
    else               colOn = TFT_BLUE;

    uint16_t colOff = TFT_DARKGREY;

    bool on = ledLevel[idx];                 // état logique de la LED
    uint16_t fillCol = on ? colOn : colOff;  // couleur du cercle

    // Circle is redrawn each refresh; full-screen clear is not required
    tft.fillCircle(x, centerY, radius, fillCol);

    // Durée restante si timer actif pour cette LED
    if (ledTimerActive[idx]) {
      long remainMs = (long)ledOffAtMs[idx] - (long)millis();
      if (remainMs < 0) remainMs = 0;
      int remainS = remainMs / 1000;

      tft.setTextDatum(MC_DATUM); // centre du texte
      tft.setTextColor(TFT_WHITE, fillCol);
      tft.setTextFont(4);         // Font used for countdown text
      tft.drawString(String(remainS), x, centerY);

    }
  }

  // ---------- Zone de texte en bas ----------
  if (tftTextDirty) { 
    int textY = 150;

    // Clear only the text area
    tft.fillRect(0, textY, tft.width(), tft.height() - textY, TFT_BLACK);

    tft.setTextDatum(TL_DATUM);          // coin haut-gauche pour le texte
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextFont(4);                  // Font used for message text
    // pas de setTextSize ici
    tft.setCursor(10, textY);

    if (tftMessage.length() == 0) {
      tft.println("Aucune commande.");
    } else {
      tft.println(tftMessage);
    }

    tftTextDirty = false;  // texte à jour, plus besoin de le redessiner
  }

}

// Appelée depuis handleCommand pour mettre à jour le message bas + redessiner
void showCommandOnTFT(const char* action,
                      const char* color,
                      const char* state,
                      int duration_s,
                      const char* message)
{
  if (message && strlen(message) > 0) {
    tftMessage = String(message);
  } else {
    tftMessage = "";
  }
  tftTextDirty = true;      // on indique qu'il faut redessiner la zone texte
}

// ---------- Handler /command ----------
void handleCommand()
{
  if (!server.hasArg("plain")) {
    server.send(400, "text/plain", "Missing body");
    return;
  }

  String body = server.arg("plain");
  Serial.println("JSON recu :");
  Serial.println(body);

  StaticJsonDocument<512> doc;
  DeserializationError err = deserializeJson(doc, body);
  if (err) {
    Serial.print("Erreur JSON: ");
    Serial.println(err.c_str());
    server.send(400, "text/plain", "JSON parse error");
    return;
  }

  // ---- Effacer l'écran de boot à la première commande ----
  if (!bootScreenCleared) {
    tft.fillScreen(TFT_BLACK);   // Clear boot screen on first command
    bootScreenCleared = true;    // One-time clear flag
  }

  // ==== NOUVEAU FORMAT : {"actions":[{ ... }]} ====
  JsonArray actions = doc["actions"].as<JsonArray>();
  if (!actions || actions.size() == 0) {
    Serial.println("JSON sans tableau 'actions'");
    server.send(400, "text/plain", "JSON format error");
    return;
  }

  // Parcours de TOUTES les actions
  for (JsonObject a : actions) {
    const char* type  = a["type"]        | "unknown";
    const char* state = a["state"]       | "off";
    int  duration_s   = a["duration_s"]  | 0;
    int  blink_ms     = a["blink_period_ms"] | 0;
    const char* message = a["message"]   | "";

    JsonArray colorsArr = a["colors"].as<JsonArray>();

    // ----- ACTION LED -----
    if (strcmp(type, "set_led") == 0) {

      // If colors is missing/empty, apply to all LEDs
      if (!colorsArr || colorsArr.size() == 0) {
        for (int idx = 0; idx < 3; idx++) {
          applyLedState(idx, state, duration_s, blink_ms);
        }
        
      } else {
        // Sinon on applique sur chaque couleur demandée
        for (JsonVariant v : colorsArr) {
          const char* cstr = v.as<const char*>();
          if (!cstr) continue;
          int idx = colorToIndex(String(cstr));
          if (idx < 0) continue;

          applyLedState(idx, state, duration_s, blink_ms);

         
        }
      }
    }

    // ----- ACTION TEXTE -----
    else if (strcmp(type, "display_text") == 0) {
      // On ne touche pas aux LEDs, on met juste à jour le message texte
      showCommandOnTFT(type, "-", "-", 0, message);
    }

  }

  // Réponse HTTP
  StaticJsonDocument<128> resp;
  resp["status"] = "ok";
  String out;
  serializeJson(resp, out);
  server.send(200, "application/json", out);
}

// --------- Setup ---------
void setup()
{
  Serial.begin(115200);
  delay(1000);

  // LEDs
  pinMode(LED_R, OUTPUT);
  pinMode(LED_G, OUTPUT);
  pinMode(LED_B, OUTPUT);
  setLedColor("red", "off");

  // TFT
  tft.init();
  tft.setRotation(1); // paysage
  tft.setTextFont(4);   // jolie police pour les textes de boot aussi
  cx = tft.width() / 2;
  cy = tft.height() / 2;

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
 
  tft.setCursor(10, 10);
  tft.println("Boot ESP32...");
  tft.println("Connexion WiFi...");

    // ====== WIFI avec debug + timeout ======
    Serial.println();
    Serial.println("WiFi connect...");
    Serial.print("Connexion a : ");
    Serial.println(WIFI_SSID);

    // Nettoyer les anciennes connexions
    WiFi.disconnect(true, true);
    delay(1000);

    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
      int s = WiFi.status();
      Serial.print("Attente WiFi... status=");
      Serial.println(s);      // WiFi.status() diagnostic
      delay(1000);
    }

    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("WiFi OK !");
      Serial.print("IP: ");
      Serial.println(WiFi.localIP());

      tft.println("WiFi OK !");
      tft.print("IP: ");
      tft.println(WiFi.localIP().toString());
    } else {
      Serial.println("ECHEC connexion WiFi");
      Serial.print("Dernier status = ");
      Serial.println(WiFi.status());

      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.println("WiFi ECHEC !");
      tft.print("status=");
      tft.println(WiFi.status());

      // On ne démarre PAS le serveur si pas de WiFi
      return;
    }
    // ====== FIN WIFI ======

  // HTTP server
  server.on("/command", HTTP_POST, handleCommand);
  server.begin();
  Serial.println("Serveur HTTP demarre sur /command");

  tftMessage = "";
  tftTextDirty = true;  // permet d'afficher "Aucune commande." après le boot
  // drawTftStatus() is refreshed in loop()

}

// ---------- Loop ----------
void loop()
{
  server.handleClient();

  unsigned long now = millis();

  for (int idx = 0; idx < 3; idx++) {
    int pin = indexToPin(idx);
    if (pin < 0) continue;

    // Timer d'extinction (durée finie)
    if (ledTimerActive[idx] && (long)(now - ledOffAtMs[idx]) >= 0) {
      digitalWrite(pin, LOW);
      ledTimerActive[idx] = false;
      ledBlinkActive[idx] = false;
      ledLevel[idx] = false;
   
    }

    // Clignotement
    if (ledBlinkActive[idx] && (long)(now - ledNextToggleMs[idx]) >= 0) {
      ledLevel[idx] = !ledLevel[idx];
      digitalWrite(pin, ledLevel[idx] ? HIGH : LOW);
      ledNextToggleMs[idx] = now + ledBlinkPeriodMs[idx];      

    }
  }

  // Rafraîchir périodiquement l'affichage des cercles (et le texte seulement s'il a changé)
  if (bootScreenCleared && millis() - lastTftRefresh > 200) {
    drawTftStatus();          // cercles toujours, texte seulement si tftTextDirty = true
    lastTftRefresh = millis();
  }
}
